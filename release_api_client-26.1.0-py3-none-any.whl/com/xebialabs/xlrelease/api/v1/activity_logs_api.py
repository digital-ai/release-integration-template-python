from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.activity_log import ActivityLogEntry


class ActivityLogsApi:
    """Operations on activity logs."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the ActivityLogsApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getActivityLogs(self, containerId: str) -> list[ActivityLogEntry]:
        """
        Gets activity logs for a container (Release, Task, Delivery, or Trigger).

        :param containerId: the container identifier.
        :return: a list of activity log entries.
        """
        response = self.api.get(f"/api/v1/activities/{containerId}")
        return ActivityLogEntry.from_response_to_list(response)
