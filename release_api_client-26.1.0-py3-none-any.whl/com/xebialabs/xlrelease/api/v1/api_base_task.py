from typing import Dict, Type, TypeVar

from digitalai.release.integration import BaseTask
from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.api.v1.activity_logs_api import ActivityLogsApi
from com.xebialabs.xlrelease.api.v1.application_api import ApplicationApi
from com.xebialabs.xlrelease.api.v1.archive_api import ArchiveApi
from com.xebialabs.xlrelease.api.v1.attachment_api import AttachmentApi
from com.xebialabs.xlrelease.api.v1.category_api import CategoryApi
from com.xebialabs.xlrelease.api.v1.configuration_api import ConfigurationApi
from com.xebialabs.xlrelease.api.v1.delivery_api import DeliveryApi
from com.xebialabs.xlrelease.api.v1.delivery_pattern_api import DeliveryPatternApi
from com.xebialabs.xlrelease.api.v1.dsl_api import DslApi
from com.xebialabs.xlrelease.api.v1.environment_api import EnvironmentApi
from com.xebialabs.xlrelease.api.v1.environment_label_api import EnvironmentLabelApi
from com.xebialabs.xlrelease.api.v1.environment_reservation_api import (
    EnvironmentReservationApi,
)
from com.xebialabs.xlrelease.api.v1.environment_stage_api import EnvironmentStageApi
from com.xebialabs.xlrelease.api.v1.folder_api import FolderApi
from com.xebialabs.xlrelease.api.v1.folder_versioning_api import FolderVersioningApi
from com.xebialabs.xlrelease.api.v1.permissions_api import PermissionsApi
from com.xebialabs.xlrelease.api.v1.phase_api import PhaseApi
from com.xebialabs.xlrelease.api.v1.release_api import ReleaseApi
from com.xebialabs.xlrelease.api.v1.report_api import ReportApi
from com.xebialabs.xlrelease.api.v1.risk_api import RiskApi
from com.xebialabs.xlrelease.api.v1.roles_api import RolesApi
from com.xebialabs.xlrelease.api.v1.search_api import SearchApi
from com.xebialabs.xlrelease.api.v1.task_api import TaskApi
from com.xebialabs.xlrelease.api.v1.task_reporting_api import TaskReportingApi
from com.xebialabs.xlrelease.api.v1.team_api import TeamApi
from com.xebialabs.xlrelease.api.v1.template_api import TemplateApi
from com.xebialabs.xlrelease.api.v1.triggers_api import TriggersApi
from com.xebialabs.xlrelease.api.v1.user_api import UserApi
from com.xebialabs.xlrelease.api.v1.variable_api import VariableApi

T = TypeVar("T")


class ApiBaseTask(BaseTask):
    """
    Base class for Release container tasks that need the v1 REST API.

    Subclass this instead of :class:`BaseTask` to get a ready-to-use, lazily
    created instance of every ``com.xebialabs.xlrelease.api.v1`` wrapper as a
    property (``releaseApi``, ``phaseApi``, ``taskApi``, ...). All wrappers
    share a single :class:`ReleaseAPIClient` built from the task's
    "Run as user" context, so the client and each API object are created only
    once and only when first accessed.

    Example::

        class MyTask(ApiBaseTask):
            def execute(self) -> None:
                release = self.releaseApi.getRelease(self.get_release_id())
                self.add_comment(f"Working on {release.title}")
    """

    def __init__(self):
        super().__init__()
        self._api_client: ReleaseAPIClient = None
        self._api_instances: Dict[Type, object] = {}

    # -- client / instance management ---------------------------------------

    @property
    def apiClient(self) -> ReleaseAPIClient:
        """The shared :class:`ReleaseAPIClient`, created on first access."""
        if self._api_client is None:
            self._api_client = self.get_release_api_client()
        return self._api_client

    def _api(self, api_class: Type[T]) -> T:
        """Return a cached instance of ``api_class``, creating it on first use."""
        instance = self._api_instances.get(api_class)
        if instance is None:
            instance = api_class(self.apiClient)
            self._api_instances[api_class] = instance
        return instance

    def reset_api_clients(self) -> None:
        """Drop the cached client and API instances (e.g. to re-authenticate)."""
        self._api_client = None
        self._api_instances = {}

    # -- API wrappers -------------------------------------------------------

    @property
    def activityLogsApi(self) -> ActivityLogsApi:
        return self._api(ActivityLogsApi)

    @property
    def applicationApi(self) -> ApplicationApi:
        return self._api(ApplicationApi)

    @property
    def archiveApi(self) -> ArchiveApi:
        return self._api(ArchiveApi)

    @property
    def attachmentApi(self) -> AttachmentApi:
        return self._api(AttachmentApi)

    @property
    def categoryApi(self) -> CategoryApi:
        return self._api(CategoryApi)

    @property
    def configurationApi(self) -> ConfigurationApi:
        return self._api(ConfigurationApi)

    @property
    def deliveryApi(self) -> DeliveryApi:
        return self._api(DeliveryApi)

    @property
    def deliveryPatternApi(self) -> DeliveryPatternApi:
        return self._api(DeliveryPatternApi)

    @property
    def dslApi(self) -> DslApi:
        return self._api(DslApi)

    @property
    def environmentApi(self) -> EnvironmentApi:
        return self._api(EnvironmentApi)

    @property
    def environmentLabelApi(self) -> EnvironmentLabelApi:
        return self._api(EnvironmentLabelApi)

    @property
    def environmentReservationApi(self) -> EnvironmentReservationApi:
        return self._api(EnvironmentReservationApi)

    @property
    def environmentStageApi(self) -> EnvironmentStageApi:
        return self._api(EnvironmentStageApi)

    @property
    def folderApi(self) -> FolderApi:
        return self._api(FolderApi)

    @property
    def folderVersioningApi(self) -> FolderVersioningApi:
        return self._api(FolderVersioningApi)

    @property
    def permissionsApi(self) -> PermissionsApi:
        return self._api(PermissionsApi)

    @property
    def phaseApi(self) -> PhaseApi:
        return self._api(PhaseApi)

    @property
    def releaseApi(self) -> ReleaseApi:
        return self._api(ReleaseApi)

    @property
    def reportApi(self) -> ReportApi:
        return self._api(ReportApi)

    @property
    def riskApi(self) -> RiskApi:
        return self._api(RiskApi)

    @property
    def rolesApi(self) -> RolesApi:
        return self._api(RolesApi)

    @property
    def searchApi(self) -> SearchApi:
        return self._api(SearchApi)

    @property
    def taskApi(self) -> TaskApi:
        return self._api(TaskApi)

    @property
    def taskReportingApi(self) -> TaskReportingApi:
        return self._api(TaskReportingApi)

    @property
    def teamApi(self) -> TeamApi:
        return self._api(TeamApi)

    @property
    def templateApi(self) -> TemplateApi:
        return self._api(TemplateApi)

    @property
    def triggersApi(self) -> TriggersApi:
        return self._api(TriggersApi)

    @property
    def userApi(self) -> UserApi:
        return self._api(UserApi)

    @property
    def variableApi(self) -> VariableApi:
        return self._api(VariableApi)
