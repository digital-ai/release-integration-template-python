from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.environment import (
    Application,
    ApplicationFilters,
)


class ApplicationApi:
    """Operations on applications."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the ApplicationApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def createApplication(self, applicationForm: Application) -> Application:
        """
        Creates a new application.

        :param applicationForm: an Application (form) describing the new application.
        :return: the created application.
        """
        response = self.api.post(
            "/api/v1/applications",
            json=applicationForm.model_dump(exclude_none=True)
        )
        return Application.from_response(response)

    def getApplication(self, applicationId: str) -> Application:
        """
        Gets an application by id.

        :param applicationId: the application identifier.
        :return: the application.
        """
        response = self.api.get(f"/api/v1/applications/{applicationId}")
        return Application.from_response(response)

    def updateApplication(self, applicationId: str, applicationForm: Application) -> Application:
        """
        Updates an existing application.

        :param applicationId: the application identifier.
        :param applicationForm: an Application (form) describing the new properties.
        :return: the updated application.
        """
        response = self.api.put(
            f"/api/v1/applications/{applicationId}",
            json=applicationForm.model_dump(exclude_none=True)
        )
        return Application.from_response(response)

    def searchApplications(self, applicationFilters: ApplicationFilters | None = None) -> list[Application]:
        """
        Searches applications by filters.

        :param applicationFilters: the search criteria.
        :return: the list of matching applications.
        """
        body = applicationFilters.model_dump(exclude_none=True) if applicationFilters else {}
        response = self.api.post("/api/v1/applications/search", json=body)
        return Application.from_response_to_list(response)

    def deleteApplication(self, applicationId: str) -> None:
        """
        Deletes an application.

        :param applicationId: the application identifier.
        """
        response = self.api.delete(f"/api/v1/applications/{applicationId}")
        response.raise_for_status()

    # --- Convenience aliases matching the Jython script API ---

    def create(self, application: Application) -> Application:
        """
        Creates a new application.

        :param application: an Application object describing the new application.
        :return: the created application.
        """
        return self.createApplication(application)

    def update(self, application: Application) -> Application:
        """
        Updates an existing application.

        :param application: an Application object describing the new properties.
        :return: the updated application.
        """
        if not application.id:
            raise ValueError("application.id must be set to update an application")
        return self.updateApplication(application.id, application)

    def search(self, filters: ApplicationFilters | None = None) -> list[Application]:
        """
        Searches applications by filters.

        :param filters: the search criteria.
        :return: the list of matching applications.
        """
        return self.searchApplications(filters)
