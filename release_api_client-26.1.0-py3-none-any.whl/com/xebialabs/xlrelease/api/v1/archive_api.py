from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.release import Release


class ArchiveApi:
    """Operations on archived releases."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the ArchiveApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getArchivedRelease(self, releaseId: str) -> Release:
        """
        Returns the archived release for the given ID.

        :param releaseId: the identifier of the release.
        :return: the archived release.
        """
        response = self.api.get(f"/api/v1/releases/archived/{releaseId}")
        return Release.from_response(response)

    def searchArchivedReleases(
            self,
            title: str | None = None,
            tags: list[str] | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Searches archived releases.

        :param title: filter by release title.
        :param tags: filter by release tags.
        :param page: the page of results to return.
        :param resultsPerPage: the number of results per page.
        :return: the list of matching archived releases.
        """
        body = {"onlyArchived": True}
        if title is not None:
            body["title"] = title
        if tags is not None:
            body["tags"] = tags
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.post("/api/v1/releases/search", json=body, params=params)
        return Release.from_response_to_list(response)
