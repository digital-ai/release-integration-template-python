from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.attachment import Attachment


class AttachmentApi:
    """Operations on attachments."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the AttachmentApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getAttachment(self, attachmentId: str) -> bytes:
        """
        Returns the attachment file with the given ID.

        :param attachmentId: the identifier of the attachment.
        :return: the attachment file content as bytes.
        """
        response = self.api.get(
            f"/api/v1/releases/attachments/{attachmentId}",
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response.content

    def addAttachment(self, taskId: str, fileName: str, fileBytes: bytes) -> Attachment:
        """
        Adds one attachment file to a task.

        :param taskId: the task identifier.
        :param fileName: the name of the attachment file.
        :param fileBytes: the file content as bytes.
        :return: the domain object of the uploaded attachment.
        """
        files = {"file": (fileName, fileBytes)}
        response = self.api.post(
            f"/api/v1/tasks/{taskId}/attachments",
            files=files
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return Attachment.model_validate(data[0])
        return Attachment.model_validate(data)

    def addAttachments(self, taskId: str, fileList: list[tuple[str, bytes]]) -> list[Attachment]:
        """
        Adds multiple attachment files to a task.

        :param taskId: the task identifier.
        :param fileList: list of (fileName, fileBytes) tuples.
        :return: list of uploaded Attachment domain objects.
        """
        files = [("file", (name, content)) for name, content in fileList]
        response = self.api.post(
            f"/api/v1/tasks/{taskId}/attachments",
            files=files
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return [Attachment.model_validate(item) for item in data]
        return [Attachment.model_validate(data)]

    def deleteAttachment(self, taskId: str, attachmentId: str) -> None:
        """
        Deletes an attachment from a task.

        :param taskId: the task identifier.
        :param attachmentId: the attachment identifier.
        """
        response = self.api.delete(f"/api/v1/tasks/{taskId}/attachments/{attachmentId}")
        response.raise_for_status()
