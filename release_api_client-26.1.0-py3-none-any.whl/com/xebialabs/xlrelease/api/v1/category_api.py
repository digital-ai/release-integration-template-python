from __future__ import annotations

from typing import Any

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.category import (
    Category,
    CategoryFilters,
    CategoryView,
)


class CategoryApi:
    """Operations on categories."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the CategoryApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def searchCategoriesPage(
            self,
            categoryFilters: CategoryFilters | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> dict[str, Any]:
        """
        Searches categories by filters, returning a page object.

        :param categoryFilters: the search criteria (mapped to query parameters).
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default and maximum value is 100.
        :return: the raw page object containing matching categories.
        """
        params: dict[str, Any] = {}
        if categoryFilters is not None:
            params.update(categoryFilters.model_dump(exclude_none=True))
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get("/api/v1/categories", params=params)
        response.raise_for_status()
        return response.json()

    def searchCategories(
            self,
            categoryFilters: CategoryFilters | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[CategoryView]:
        """
        Searches categories by filters.

        :param categoryFilters: the search criteria.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default and maximum value is 100.
        :return: the list of matching categories.
        """
        page_obj = self.searchCategoriesPage(categoryFilters, page, resultsPerPage)
        content = page_obj.get("content", []) if isinstance(page_obj, dict) else []
        return [CategoryView.from_dict(item) for item in content]

    def addCategory(self, category: Category) -> Category:
        """
        Creates a new category.

        :param category: the content of the category to create.
        :return: the created category.
        """
        response = self.api.post(
            "/api/v1/categories",
            json=category.model_dump(exclude_none=True)
        )
        return Category.from_response(response)

    def updateCategory(self, ciUid: int, category: Category) -> Category:
        """
        Updates a category.

        :param ciUid: the identifier of the category.
        :param category: the new content of the category.
        :return: the updated category.
        """
        body = category.model_dump(exclude_none=True)
        # The REST representation identifies a category by its string "id"; the
        # "ciUid" property is not accepted in the request body.
        body.pop("ciUid", None)
        body.setdefault("id", str(ciUid))
        response = self.api.put(
            f"/api/v1/categories/{ciUid}",
            json=body
        )
        return Category.from_response(response)

    def deleteCategory(self, ciUid: int) -> None:
        """
        Deletes a category.

        :param ciUid: the identifier of the category.
        """
        response = self.api.delete(f"/api/v1/categories/{ciUid}")
        response.raise_for_status()
