from __future__ import annotations

from typing import Any

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.configuration import (
    Configuration,
    SystemMessageSettings,
)
from com.xebialabs.xlrelease.domain.variable import Variable


class ConfigurationApi:
    """Operations on shared configurations and global variables."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the ConfigurationApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getGlobalVariables(self) -> list[Variable]:
        """
        Returns global variables.

        :return: a list of global variables.
        """
        response = self.api.get("/api/v1/config/Configuration/variables/global")
        return Variable.from_response_to_list(response)

    def getGlobalVariableValues(self) -> dict[str, str]:
        """
        Returns global variable values.

        :return: a map of global variable values.
        """
        response = self.api.get("/api/v1/config/Configuration/variableValues/global")
        response.raise_for_status()
        return response.json()

    def getGlobalVariable(self, variableId: str) -> Variable:
        """
        Returns a global variable by ID.

        :param variableId: the variable identifier.
        :return: the variable.
        """
        response = self.api.get(f"/api/v1/config/{variableId}")
        return Variable.from_response(response)

    def addGlobalVariable(self, variable: Variable) -> Variable:
        """
        Adds a global variable.

        :param variable: the variable to add.
        :return: the added variable.
        """
        response = self.api.post(
            "/api/v1/config/Configuration/variables/global",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def deleteGlobalVariable(self, variableId: str) -> None:
        """
        Deletes a global variable.

        :param variableId: the variable identifier.
        """
        response = self.api.delete(f"/api/v1/config/{variableId}")
        response.raise_for_status()

    def getGlobalVariablePossibleValues(self, variableId: str) -> list:
        """
        Returns possible values for a global variable.

        :param variableId: the variable identifier.
        :return: possible values for the variable.
        """
        response = self.api.get(f"/api/v1/config/{variableId}/possibleValues")
        response.raise_for_status()
        return response.json()

    def searchByTypeAndTitle(
            self,
            configurationType: str | None = None,
            title: str | None = None,
            folderId: str | None = None,
            folderOnly: bool | None = None
    ) -> list[Configuration]:
        """
        Searches configurations by type and title.

        :param configurationType: the configuration type.
        :param title: the configuration title.
        :param folderId: the folder identifier.
        :param folderOnly: filter to folder only.
        :return: a list of configurations.
        """
        params = {}
        if configurationType is not None:
            params["configurationType"] = configurationType
        if title is not None:
            params["title"] = title
        if folderId is not None:
            params["folderId"] = folderId
        if folderOnly is not None:
            params["folderOnly"] = folderOnly
        response = self.api.get("/api/v1/config/byTypeAndTitle", params=params)
        return Configuration.from_response_to_list(response)

    def getConfigurations(self, configurationIds: list[str]) -> list[Configuration]:
        """
        Gets configurations by IDs.

        :param configurationIds: the list of configuration IDs.
        :return: a list of configurations.
        """
        response = self.api.post("/api/v1/config/byIds", json=configurationIds)
        return Configuration.from_response_to_list(response)

    def getConfiguration(self, configurationId: str) -> Configuration:
        """
        Gets a configuration by ID.

        :param configurationId: the configuration identifier.
        :return: the configuration.
        """
        response = self.api.get(f"/api/v1/config/{configurationId}")
        return Configuration.from_response(response)

    def addConfiguration(self, configuration: Configuration) -> Configuration:
        """
        Adds a new configuration.

        :param configuration: the configuration to add.
        :return: the added configuration.
        """
        response = self.api.post(
            "/api/v1/config",
            json=configuration.model_dump(exclude_none=True)
        )
        return Configuration.from_response(response)

    def deleteConfiguration(self, configurationId: str) -> None:
        """
        Deletes a configuration.

        :param configurationId: the configuration identifier.
        """
        response = self.api.delete(f"/api/v1/config/{configurationId}")
        response.raise_for_status()

    def getSystemMessage(self) -> SystemMessageSettings:
        """
        Returns system message settings.

        :return: the system message settings.
        """
        response = self.api.get("/api/v1/config/system-message")
        return SystemMessageSettings.from_response(response)

    def updateSystemMessage(self, systemMessageSettings: SystemMessageSettings) -> SystemMessageSettings:
        """
        Updates system message settings.

        :param systemMessageSettings: the settings to update.
        :return: the updated settings.
        """
        response = self.api.put(
            "/api/v1/config/system-message",
            json=systemMessageSettings.model_dump(exclude_none=True)
        )
        return SystemMessageSettings.from_response(response)

    def duplicateConfiguration(self, configurationId: str) -> Configuration:
        """
        Duplicates a configuration.

        :param configurationId: the configuration identifier.
        :return: the duplicated configuration.
        """
        response = self.api.post(f"/api/v1/config/{configurationId}/copy")
        return Configuration.from_response(response)

    def updateGlobalVariable(self, variableId: str, variable: Variable) -> Variable:
        """
        Updates a global variable.

        :param variableId: the variable identifier.
        :param variable: the updated variable.
        :return: the updated variable.
        """
        response = self.api.put(
            f"/api/v1/config/{variableId}",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def updateConfiguration(self, configurationId: str, configuration: Configuration) -> Configuration:
        """
        Updates a configuration.

        :param configurationId: the configuration identifier.
        :param configuration: the updated configuration.
        :return: the updated configuration.
        """
        response = self.api.put(
            f"/api/v1/config/{configurationId}",
            json=configuration.model_dump(exclude_none=True)
        )
        return Configuration.from_response(response)

    def checkStatus(self, configurationId: str) -> dict:
        """
        Checks the status of a shared configuration.

        :param configurationId: the configuration identifier.
        :return: the status response.
        """
        response = self.api.post(f"/api/v1/config/{configurationId}/status")
        response.raise_for_status()
        return response.json()
