from __future__ import annotations

import uuid

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.delivery import (
    CreateDelivery,
    Delivery,
    DeliveryFilters,
    Stage,
    TrackedItem,
    Transition,
)


class DeliveryApi:
    """Operations on deliveries."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the DeliveryApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getDelivery(self, deliveryId: str) -> Delivery:
        """
        Gets a delivery by ID.

        :param deliveryId: the delivery identifier.
        :return: the delivery.
        """
        response = self.api.get(f"/api/v1/deliveries/{deliveryId}")
        return Delivery.from_response(response)

    def updateDelivery(self, deliveryId: str, delivery: Delivery) -> Delivery:
        """
        Updates a delivery.

        :param deliveryId: the delivery identifier.
        :param delivery: the updated delivery.
        :return: the updated delivery.
        """
        response = self.api.put(
            f"/api/v1/deliveries/{deliveryId}",
            json=delivery.model_dump(exclude_none=True)
        )
        return Delivery.from_response(response)

    def deleteDelivery(self, deliveryId: str) -> None:
        """
        Deletes a delivery.

        :param deliveryId: the delivery identifier.
        """
        response = self.api.delete(f"/api/v1/deliveries/{deliveryId}")
        response.raise_for_status()

    def searchDeliveries(
            self,
            deliveryFilters: DeliveryFilters,
            page: int | None = None,
            resultsPerPage: int | None = None,
            orderBy: str | None = None
    ) -> list[Delivery]:
        """
        Searches deliveries by filters.

        :param deliveryFilters: the search criteria.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :param orderBy: the ordering mode (e.g. START_DATE).
        :return: the list of matching deliveries.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if orderBy is not None:
            params["orderBy"] = orderBy
        response = self.api.post(
            "/api/v1/deliveries/search",
            json=deliveryFilters.model_dump(exclude_none=True),
            params=params
        )
        return Delivery.from_response_to_list(response)

    def getReleases(self, deliveryId: str) -> list:
        """
        Gets releases for a delivery.

        :param deliveryId: the delivery identifier.
        :return: a list of delivery release info objects.
        """
        response = self.api.get(f"/api/v1/deliveries/{deliveryId}/releases")
        response.raise_for_status()
        return response.json()

    def getDeliveryTimeline(self, deliveryId: str) -> dict:
        """
        Returns the timeline of a delivery.

        :param deliveryId: the delivery identifier.
        :return: the delivery timeline.
        """
        response = self.api.get(f"/api/v1/deliveries/{deliveryId}/timeline")
        response.raise_for_status()
        return response.json()

    def createTrackedItem(self, deliveryId: str, item: TrackedItem) -> TrackedItem:
        """
        Creates a tracked item in a delivery.

        :param deliveryId: the delivery identifier.
        :param item: the tracked item to create.
        :return: the created tracked item.
        """
        payload = item.model_dump(exclude_none=True)
        if "id" not in payload or not payload["id"]:
            payload["id"] = str(uuid.uuid4().int)[:9]
        if "type" not in payload or not payload["type"]:
            payload["type"] = "delivery.TrackedItem"
        if "releaseIds" not in payload:
            payload["releaseIds"] = []
        if "descoped" not in payload:
            payload["descoped"] = False
        response = self.api.post(
            f"/api/v1/deliveries/{deliveryId}/tracked-items",
            json=payload
        )
        return TrackedItem.from_response(response)

    def getTrackedItems(self, deliveryId: str) -> list[TrackedItem]:
        """
        Gets tracked items for a delivery.

        :param deliveryId: the delivery identifier.
        :return: a list of tracked items.
        """
        response = self.api.get(f"/api/v1/deliveries/{deliveryId}/tracked-items")
        return TrackedItem.from_response_to_list(response)

    def updateTrackedItem(self, itemId: str, item: TrackedItem) -> TrackedItem:
        """
        Updates a tracked item.

        :param itemId: the tracked item identifier.
        :param item: the updated tracked item.
        :return: the updated tracked item.
        """
        response = self.api.put(
            f"/api/v1/deliveries/{itemId}",
            json=item.model_dump(exclude_none=True)
        )
        return TrackedItem.from_response(response)

    def deleteTrackedItem(self, itemId: str) -> None:
        """
        Deletes a tracked item.

        :param itemId: the tracked item identifier.
        """
        response = self.api.delete(f"/api/v1/deliveries/{itemId}")
        response.raise_for_status()

    def descopeTrackedItem(self, itemId: str) -> None:
        """
        Descopes a tracked item.

        :param itemId: the tracked item identifier.
        """
        response = self.api.put(f"/api/v1/deliveries/{itemId}/descope")
        response.raise_for_status()

    def rescopeTrackedItem(self, itemId: str) -> None:
        """
        Rescopes a tracked item.

        :param itemId: the tracked item identifier.
        """
        response = self.api.put(f"/api/v1/deliveries/{itemId}/rescope")
        response.raise_for_status()

    def completeTrackedItem(self, stageId: str, itemId: str, releaseId: str | None = None) -> None:
        """
        Completes a tracked item in a stage.

        :param stageId: the full stage identifier.
        :param itemId: the tracked item identifier.
        :param releaseId: the optional identifier of the release that completed the item.
        """
        if releaseId is not None:
            path = f"/api/v1/deliveries/{stageId}/{itemId}/{releaseId}/complete"
        else:
            path = f"/api/v1/deliveries/{stageId}/{itemId}/complete"
        response = self.api.put(path)
        response.raise_for_status()

    def skipTrackedItem(self, stageId: str, itemId: str) -> None:
        """
        Skips a tracked item in a stage.

        :param stageId: the full stage identifier.
        :param itemId: the tracked item identifier.
        """
        response = self.api.put(f"/api/v1/deliveries/{stageId}/{itemId}/skip")
        response.raise_for_status()

    def resetTrackedItem(self, stageId: str, itemId: str) -> None:
        """
        Resets a tracked item in a stage.

        :param stageId: the full stage identifier.
        :param itemId: the tracked item identifier.
        """
        response = self.api.put(f"/api/v1/deliveries/{stageId}/{itemId}/reset")
        response.raise_for_status()

    def getStages(self, deliveryId: str) -> list[Stage]:
        """
        Gets stages for a delivery.

        :param deliveryId: the delivery identifier.
        :return: a list of stages.
        """
        response = self.api.get(f"/api/v1/deliveries/{deliveryId}/stages")
        return Stage.from_response_to_list(response)

    def completeStage(self, stageId: str) -> None:
        """
        Completes a stage.

        :param stageId: the stage identifier.
        """
        response = self.api.post(f"/api/v1/deliveries/{stageId}/complete")
        response.raise_for_status()

    def reopenStage(self, stageId: str) -> None:
        """
        Reopens a stage.

        :param stageId: the stage identifier.
        """
        response = self.api.post(f"/api/v1/deliveries/{stageId}/reopen")
        response.raise_for_status()

    def updateStage(self, stageId: str, stage: Stage) -> Stage:
        """
        Updates a stage.

        :param stageId: the stage identifier.
        :param stage: the updated stage.
        :return: the updated stage.
        """
        response = self.api.put(
            f"/api/v1/deliveries/{stageId}",
            json=stage.model_dump(exclude_none=True)
        )
        return Stage.from_response(response)

    def updateTransition(self, transitionId: str, transition: Transition) -> Transition:
        """
        Updates a transition.

        :param transitionId: the transition identifier.
        :param transition: the updated transition.
        :return: the updated transition.
        """
        response = self.api.put(
            f"/api/v1/deliveries/{transitionId}",
            json=transition.model_dump(exclude_none=True)
        )
        return Transition.from_response(response)

    def completeTransition(self, transitionId: str, completeTransition: dict | None = None) -> None:
        """
        Executes a transition on a delivery manually.

        :param transitionId: the full transition identifier.
        :param completeTransition: the transition completion parameters.
        """
        response = self.api.post(
            f"/api/v1/deliveries/{transitionId}/complete",
            json=completeTransition or {}
        )
        response.raise_for_status()
