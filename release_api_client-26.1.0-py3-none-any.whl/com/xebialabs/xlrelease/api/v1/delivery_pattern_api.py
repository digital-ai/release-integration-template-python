from __future__ import annotations

import uuid

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.delivery import (
    CreateDelivery,
    Delivery,
    DeliveryPatternFilters,
    Stage,
    TrackedItem,
    Transition,
)


class DeliveryPatternApi:
    """Operations on delivery patterns."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the DeliveryPatternApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def createPattern(self, pattern: Delivery) -> Delivery:
        """
        Creates a delivery pattern.

        :param pattern: the delivery pattern to create.
        :return: the created pattern.
        """
        payload = pattern.model_dump(exclude_none=True)
        if "id" not in payload or not payload["id"]:
            payload["id"] = f"Deliveries/Delivery{uuid.uuid4().hex}"
        if "type" not in payload or not payload["type"]:
            payload["type"] = "delivery.Delivery"
        if "status" not in payload or not payload["status"]:
            payload["status"] = "TEMPLATE"
        if "releaseIds" not in payload:
            payload["releaseIds"] = []
        if "stages" not in payload:
            payload["stages"] = []
        if "trackedItems" not in payload:
            payload["trackedItems"] = []
        if "subscribers" not in payload:
            payload["subscribers"] = []
        if "autoComplete" not in payload:
            payload["autoComplete"] = False
        response = self.api.post(
            "/api/v1/delivery-patterns",
            json=payload
        )
        return Delivery.from_response(response)

    def getPattern(self, patternId: str) -> Delivery:
        """
        Gets a delivery pattern by ID.

        :param patternId: the pattern identifier.
        :return: the delivery pattern.
        """
        response = self.api.get(f"/api/v1/delivery-patterns/{patternId}")
        return Delivery.from_response(response)

    def getPatternByIdOrTitle(self, patternIdOrTitle: str) -> Delivery:
        """
        Gets a delivery pattern by ID or title.

        :param patternIdOrTitle: the pattern ID or title.
        :return: the delivery pattern.
        """
        response = self.api.get(f"/api/v1/delivery-patterns/{patternIdOrTitle}")
        return Delivery.from_response(response)

    def updatePattern(self, patternId: str, pattern: Delivery) -> Delivery:
        """
        Updates a delivery pattern.

        :param patternId: the pattern identifier.
        :param pattern: the updated pattern.
        :return: the updated pattern.
        """
        response = self.api.put(
            f"/api/v1/delivery-patterns/{patternId}",
            json=pattern.model_dump(exclude_none=True)
        )
        return Delivery.from_response(response)

    def deletePattern(self, patternId: str) -> None:
        """
        Deletes a delivery pattern.

        :param patternId: the pattern identifier.
        """
        response = self.api.delete(f"/api/v1/delivery-patterns/{patternId}")
        response.raise_for_status()

    def checkTitleUnique(self, validation: dict) -> bool:
        """
        Checks whether a delivery pattern title is unique.

        :param validation: a dict describing the pattern to validate (e.g. ``{"title": ..., "id": ...}``).
        :return: True if the title is unique.
        """
        response = self.api.post("/api/v1/delivery-patterns/checkTitle", json=validation)
        response.raise_for_status()
        return response.json()

    def duplicatePattern(self, patternId: str, duplicateDeliveryPattern: dict | None = None) -> Delivery:
        """
        Duplicates a delivery pattern.

        :param patternId: the pattern identifier.
        :param duplicateDeliveryPattern: parameters for the duplicate (e.g. ``{"title": ...}``).
        :return: the duplicated pattern.
        """
        response = self.api.post(
            f"/api/v1/delivery-patterns/{patternId}/duplicate",
            json=duplicateDeliveryPattern or {}
        )
        return Delivery.from_response(response)

    def createDeliveryFromPattern(self, patternId: str, createDelivery: CreateDelivery) -> Delivery:
        """
        Creates a delivery from a pattern.

        :param patternId: the pattern identifier.
        :param createDelivery: the parameters for the new delivery.
        :return: the newly created delivery.
        """
        response = self.api.post(
            f"/api/v1/delivery-patterns/{patternId}/create",
            json=createDelivery.model_dump(exclude_none=True)
        )
        return Delivery.from_response(response)

    def searchPatterns(
            self,
            filters: DeliveryPatternFilters,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Delivery]:
        """
        Searches delivery patterns.

        :param filters: the search criteria.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :return: the list of matching patterns.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.post(
            "/api/v1/delivery-patterns/search",
            json=filters.model_dump(exclude_none=True),
            params=params
        )
        return Delivery.from_response_to_list(response)

    def createStage(self, patternId: str, stage: Stage, position: int | None = None) -> Stage:
        """
        Creates a stage in a delivery pattern.

        :param patternId: the pattern identifier.
        :param stage: the stage to create.
        :param position: the position for the stage.
        :return: the created stage.
        """
        payload = stage.model_dump(exclude_none=True)
        if "id" not in payload or not payload["id"]:
            payload["id"] = f"{patternId}/Stage{uuid.uuid4().hex}"
        if "type" not in payload or not payload["type"]:
            payload["type"] = "delivery.Stage"
        if "status" not in payload or not payload["status"]:
            payload["status"] = "OPEN"
        if "items" not in payload:
            payload["items"] = []
        path = f"/api/v1/delivery-patterns/{patternId}/stages"
        if position is not None:
            path = f"{path}/{position}"
        response = self.api.post(path, json=payload)
        return Stage.from_response(response)

    def getStages(self, patternId: str) -> list[Stage]:
        """
        Gets stages for a delivery pattern.

        :param patternId: the pattern identifier.
        :return: a list of stages.
        """
        response = self.api.get(f"/api/v1/delivery-patterns/{patternId}/stages")
        return Stage.from_response_to_list(response)

    def updateStage(self, stageId: str, stage: Stage) -> Stage:
        """
        Updates a stage.

        :param stageId: the stage identifier.
        :param stage: the updated stage.
        :return: the updated stage.
        """
        response = self.api.put(
            f"/api/v1/delivery-patterns/{stageId}",
            json=stage.model_dump(exclude_none=True)
        )
        return Stage.from_response(response)

    def updateStageFromBatch(self, stageId: str, stage: Stage) -> Stage:
        """
        Updates a stage as part of a batch operation.

        :param stageId: the stage identifier.
        :param stage: the updated stage.
        :return: the updated stage.
        """
        response = self.api.put(
            f"/api/v1/delivery-patterns/{stageId}/batched",
            json=stage.model_dump(exclude_none=True)
        )
        return Stage.from_response(response)

    def deleteStage(self, stageId: str) -> None:
        """
        Deletes a stage.

        :param stageId: the stage identifier.
        """
        response = self.api.delete(f"/api/v1/delivery-patterns/{stageId}")
        response.raise_for_status()

    def createTransition(self, stageId: str, transition: Transition) -> Transition:
        """
        Creates a transition in a stage.

        :param stageId: the stage identifier.
        :param transition: the transition to create.
        :return: the created transition.
        """
        response = self.api.post(
            f"/api/v1/delivery-patterns/{stageId}/transitions",
            json=transition.model_dump(exclude_none=True)
        )
        return Transition.from_response(response)

    def updateTransition(self, transitionId: str, transition: Transition) -> Transition:
        """
        Updates a transition.

        :param transitionId: the transition identifier.
        :param transition: the updated transition.
        :return: the updated transition.
        """
        response = self.api.put(
            f"/api/v1/delivery-patterns/{transitionId}",
            json=transition.model_dump(exclude_none=True)
        )
        return Transition.from_response(response)

    def deleteTransition(self, transitionId: str) -> None:
        """
        Deletes a transition.

        :param transitionId: the transition identifier.
        """
        response = self.api.delete(f"/api/v1/delivery-patterns/{transitionId}")
        response.raise_for_status()

    def createTrackedItem(self, patternId: str, item: TrackedItem) -> TrackedItem:
        """
        Creates a tracked item in a delivery pattern.

        :param patternId: the pattern identifier.
        :param item: the tracked item to create.
        :return: the created tracked item.
        """
        payload = item.model_dump(exclude_none=True)
        if "id" not in payload or not payload["id"]:
            payload["id"] = str(uuid.uuid4().int)[:9]
        if "type" not in payload or not payload["type"]:
            payload["type"] = "delivery.TrackedItem"
        if "releaseIds" not in payload:
            payload["releaseIds"] = []
        if "descoped" not in payload:
            payload["descoped"] = False
        response = self.api.post(
            f"/api/v1/delivery-patterns/{patternId}/tracked-items",
            json=payload
        )
        return TrackedItem.from_response(response)

    def getTrackedItems(self, patternId: str) -> list[TrackedItem]:
        """
        Gets tracked items for a delivery pattern.

        :param patternId: the pattern identifier.
        :return: a list of tracked items.
        """
        response = self.api.get(f"/api/v1/delivery-patterns/{patternId}/tracked-items")
        return TrackedItem.from_response_to_list(response)

    def updateTrackedItem(self, itemId: str, item: TrackedItem) -> TrackedItem:
        """
        Updates a tracked item.

        :param itemId: the tracked item identifier.
        :param item: the updated tracked item.
        :return: the updated tracked item.
        """
        response = self.api.put(
            f"/api/v1/delivery-patterns/{itemId}",
            json=item.model_dump(exclude_none=True)
        )
        return TrackedItem.from_response(response)

    def deleteTrackedItem(self, itemId: str) -> None:
        """
        Deletes a tracked item.

        :param itemId: the tracked item identifier.
        """
        response = self.api.delete(f"/api/v1/delivery-patterns/{itemId}")
        response.raise_for_status()
