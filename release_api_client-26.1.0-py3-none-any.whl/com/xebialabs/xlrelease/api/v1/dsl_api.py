from __future__ import annotations

from typing import Any

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.release import Release


class DslApi:
    """Operations with release DSL."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the DslApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def previewExportTemplateToXFile(self, templateId: str, asTemplate: bool = False) -> str:
        """
        Shows a DSL preview of a given template.

        :param templateId: the template identifier.
        :param asTemplate: if True, renders as a template; otherwise renders as a release.
        :return: the UTF-8 encoded DSL string.
        """
        response = self.api.get(
            f"/api/v1/dsl/preview/{templateId}",
            params={"exportTemplate": asTemplate},
            headers={"Accept": "text/plain"}
        )
        response.raise_for_status()
        return response.text

    def exportTemplateToXFile(self, templateId: str, asTemplate: bool = False) -> Any:
        """
        Exports a given template into DSL.

        :param templateId: the template identifier.
        :param asTemplate: if True, renders as a template; otherwise renders as a release.
        :return: the raw HTTP response containing a zip file with the DSL and attachments.
        """
        response = self.api.get(
            f"/api/v1/dsl/export/{templateId}",
            params={"exportTemplate": asTemplate},
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response

    def exportTemplate(self, template: Release, asTemplate: bool = False) -> str:
        """
        Exports a template as DSL.

        :param template: the template to export.
        :param asTemplate: if True, renders as a template; otherwise renders as a release.
        :return: the DSL string.
        """
        if not template.id:
            raise ValueError("template.id must be set to export a template")
        return self.previewExportTemplateToXFile(template.id, asTemplate)
