from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.environment import (
    Application,
    Environment,
    EnvironmentFilters,
    EnvironmentReservation,
)


class EnvironmentApi:
    """Operations on environments."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the EnvironmentApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    @staticmethod
    def _to_form_body(environmentForm: Environment) -> dict:
        """Builds the request body, deriving the form ``stageId`` from a nested stage."""
        body = environmentForm.model_dump(exclude_none=True)
        if not body.get("stageId") and environmentForm.stage and environmentForm.stage.id:
            body["stageId"] = environmentForm.stage.id
        return body

    def createEnvironment(self, environmentForm: Environment) -> Environment:
        """
        Creates a new environment.

        :param environmentForm: an Environment (form) describing the new environment.
            The stage may be provided either as a nested ``stage`` or as ``stageId``.
        :return: the created environment.
        """
        response = self.api.post(
            "/api/v1/environments",
            json=self._to_form_body(environmentForm)
        )
        return Environment.from_response(response)

    def getEnvironment(self, environmentId: str) -> Environment:
        """
        Gets an environment by id.

        :param environmentId: the environment identifier.
        :return: the environment.
        """
        response = self.api.get(f"/api/v1/environments/{environmentId}")
        return Environment.from_response(response)

    def updateEnvironment(self, environmentId: str, environmentForm: Environment) -> Environment:
        """
        Updates an existing environment.

        :param environmentId: the environment identifier.
        :param environmentForm: an Environment (form) describing the new properties.
        :return: the updated environment.
        """
        response = self.api.put(
            f"/api/v1/environments/{environmentId}",
            json=self._to_form_body(environmentForm)
        )
        return Environment.from_response(response)

    def searchEnvironments(self, environmentFilters: EnvironmentFilters | None = None) -> list[Environment]:
        """
        Searches environments by filters.

        :param environmentFilters: the search criteria.
        :return: the list of matching environments.
        """
        body = environmentFilters.model_dump(exclude_none=True) if environmentFilters else {}
        response = self.api.post("/api/v1/environments/search", json=body)
        return Environment.from_response_to_list(response)

    def getReservationsForEnvironment(self, environmentId: str) -> list[EnvironmentReservation]:
        """
        Gets all environment reservations for a given environment.

        :param environmentId: the environment identifier.
        :return: the list of reservations.
        """
        response = self.api.get(f"/api/v1/environments/{environmentId}/reservations")
        return EnvironmentReservation.from_response_to_list(response)

    def getDeployableApplicationsForEnvironment(self, environmentId: str) -> list[Application]:
        """
        Gets all applications that are allowed to be deployed for a given environment.

        :param environmentId: the environment identifier.
        :return: the list of applications.
        """
        response = self.api.get(f"/api/v1/environments/{environmentId}/applications")
        return Application.from_response_to_list(response)

    def delete(self, environmentId: str) -> None:
        """
        Deletes an environment.

        :param environmentId: the environment identifier.
        """
        response = self.api.delete(f"/api/v1/environments/{environmentId}")
        response.raise_for_status()

    # --- Convenience aliases matching the Jython script API ---

    def create(self, environment: Environment) -> Environment:
        """
        Creates a new environment.

        :param environment: an Environment object describing the new environment.
        :return: the created environment.
        """
        return self.createEnvironment(environment)

    def getById(self, environmentId: str) -> Environment:
        """
        Gets an environment by id.

        :param environmentId: the environment identifier.
        :return: the environment.
        """
        return self.getEnvironment(environmentId)

    def update(self, environment: Environment) -> Environment:
        """
        Updates an existing environment.

        :param environment: an Environment object describing the new properties.
        :return: the updated environment.
        """
        if not environment.id:
            raise ValueError("environment.id must be set to update an environment")
        return self.updateEnvironment(environment.id, environment)

    def search(self, filters: EnvironmentFilters | None = None) -> list[Environment]:
        """
        Searches environments by filters.

        :param filters: the search criteria.
        :return: the list of matching environments.
        """
        return self.searchEnvironments(filters)

    def getReservations(self, environmentId: str) -> list[EnvironmentReservation]:
        """
        Gets all environment reservations for a given environment.

        :param environmentId: the environment identifier.
        :return: the list of reservations.
        """
        return self.getReservationsForEnvironment(environmentId)

    def getDeployableApplications(self, environmentId: str) -> list[Application]:
        """
        Gets all applications that are allowed to be deployed for a given environment.

        :param environmentId: the environment identifier.
        :return: the list of applications.
        """
        return self.getDeployableApplicationsForEnvironment(environmentId)
