from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.environment import (
    EnvironmentLabel,
    EnvironmentLabelFilters,
)


class EnvironmentLabelApi:
    """Operations on environment labels."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the EnvironmentLabelApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def createLabel(self, labelForm: EnvironmentLabel) -> EnvironmentLabel:
        """
        Creates a new environment label.

        :param labelForm: an EnvironmentLabel (form) describing the new label.
        :return: the created environment label.
        """
        response = self.api.post(
            "/api/v1/environments/labels",
            json=labelForm.model_dump(exclude_none=True)
        )
        return EnvironmentLabel.from_response(response)

    def getLabelById(self, environmentLabelId: str) -> EnvironmentLabel:
        """
        Gets an environment label by id.

        :param environmentLabelId: the environment label identifier.
        :return: the environment label.
        """
        response = self.api.get(f"/api/v1/environments/labels/{environmentLabelId}")
        return EnvironmentLabel.from_response(response)

    def updateLabel(self, environmentLabelId: str, labelForm: EnvironmentLabel) -> EnvironmentLabel:
        """
        Updates an existing environment label.

        :param environmentLabelId: the environment label identifier.
        :param labelForm: an EnvironmentLabel (form) describing the new properties.
        :return: the updated environment label.
        """
        response = self.api.put(
            f"/api/v1/environments/labels/{environmentLabelId}",
            json=labelForm.model_dump(exclude_none=True)
        )
        return EnvironmentLabel.from_response(response)

    def searchLabels(self, filters: EnvironmentLabelFilters | None = None) -> list[EnvironmentLabel]:
        """
        Searches environment labels by filters.

        :param filters: the search criteria.
        :return: the list of matching environment labels.
        """
        body = filters.model_dump(exclude_none=True) if filters else {}
        response = self.api.post("/api/v1/environments/labels/search", json=body)
        return EnvironmentLabel.from_response_to_list(response)

    def delete(self, environmentLabelId: str) -> None:
        """
        Deletes an environment label.

        :param environmentLabelId: the environment label identifier.
        """
        response = self.api.delete(f"/api/v1/environments/labels/{environmentLabelId}")
        response.raise_for_status()

    # --- Convenience aliases matching the Jython script API ---

    def create(self, environmentLabel: EnvironmentLabel) -> EnvironmentLabel:
        """
        Creates a new environment label.

        :param environmentLabel: an EnvironmentLabel object describing the new label.
        :return: the created environment label.
        """
        return self.createLabel(environmentLabel)

    def getById(self, id: str) -> EnvironmentLabel:
        """
        Gets an environment label by id.

        :param id: the environment label identifier.
        :return: the environment label.
        """
        return self.getLabelById(id)

    def update(self, environmentLabel: EnvironmentLabel) -> EnvironmentLabel:
        """
        Updates an existing environment label.

        :param environmentLabel: an EnvironmentLabel object describing the new properties.
        :return: the updated environment label.
        """
        if not environmentLabel.id:
            raise ValueError("environmentLabel.id must be set to update a label")
        return self.updateLabel(environmentLabel.id, environmentLabel)

    def search(self, filters: EnvironmentLabelFilters | None = None) -> list[EnvironmentLabel]:
        """
        Searches environment labels by filters.

        :param filters: the search criteria.
        :return: the list of matching environment labels.
        """
        return self.searchLabels(filters)
