from __future__ import annotations

from datetime import datetime, timedelta, timezone

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.environment import (
    EnvironmentReservation,
    ReservationFilters,
)


class EnvironmentReservationApi:
    """Operations on environment reservations."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the EnvironmentReservationApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def createReservation(self, environmentReservationForm: EnvironmentReservation) -> EnvironmentReservation:
        """
        Creates a new environment reservation.

        :param environmentReservationForm: an EnvironmentReservation (form).
        :return: the created environment reservation.
        """
        response = self.api.post(
            "/api/v1/environments/reservations",
            json=environmentReservationForm.model_dump(exclude_none=True)
        )
        return EnvironmentReservation.from_response(response)

    def getReservation(self, environmentReservationId: str) -> EnvironmentReservation:
        """
        Gets an environment reservation by id.

        :param environmentReservationId: the environment reservation identifier.
        :return: the environment reservation.
        """
        response = self.api.get(f"/api/v1/environments/reservations/{environmentReservationId}")
        return EnvironmentReservation.from_response(response)

    def updateReservation(
            self,
            environmentReservationId: str,
            environmentReservationForm: EnvironmentReservation
    ) -> EnvironmentReservation:
        """
        Updates an existing environment reservation.

        :param environmentReservationId: the environment reservation identifier.
        :param environmentReservationForm: an EnvironmentReservation (form).
        :return: the updated environment reservation.
        """
        response = self.api.put(
            f"/api/v1/environments/reservations/{environmentReservationId}",
            json=environmentReservationForm.model_dump(exclude_none=True)
        )
        return EnvironmentReservation.from_response(response)

    def searchReservations(self, filters: ReservationFilters | None = None) -> list[EnvironmentReservation]:
        """
        Searches environment reservations by filters.

        :param filters: the search criteria.
        :return: the list of matching environment reservations.
        """
        body = filters.model_dump(by_alias=True, exclude_none=True) if filters else {}
        response = self.api.post("/api/v1/environments/reservations/search", json=body)
        return EnvironmentReservation.from_response_to_list(response)

    def delete(self, environmentReservationId: str) -> None:
        """
        Deletes an environment reservation.

        :param environmentReservationId: the environment reservation identifier.
        """
        response = self.api.delete(f"/api/v1/environments/reservations/{environmentReservationId}")
        response.raise_for_status()

    def addApplication(self, environmentReservationId: str, applicationId: str) -> None:
        """
        Adds an application to an environment reservation.

        :param environmentReservationId: the environment reservation identifier.
        :param applicationId: the application identifier.
        """
        response = self.api.post(
            f"/api/v1/environments/reservations/{environmentReservationId}",
            params={"applicationId": applicationId}
        )
        response.raise_for_status()

    # --- Convenience aliases matching the Jython script API ---

    def create(self, environmentReservation: EnvironmentReservation) -> EnvironmentReservation:
        """
        Creates a new environment reservation.

        :param environmentReservation: an EnvironmentReservation object.
        :return: the created environment reservation.
        """
        return self.createReservation(environmentReservation)

    def getById(self, environmentReservationId: str) -> EnvironmentReservation:
        """
        Gets an environment reservation by id.

        :param environmentReservationId: the environment reservation identifier.
        :return: the environment reservation.
        """
        return self.getReservation(environmentReservationId)

    def update(self, environmentReservation: EnvironmentReservation) -> EnvironmentReservation:
        """
        Updates an existing environment reservation.

        :param environmentReservation: an EnvironmentReservation object.
        :return: the updated environment reservation.
        """
        if not environmentReservation.id:
            raise ValueError("environmentReservation.id must be set to update a reservation")
        return self.updateReservation(environmentReservation.id, environmentReservation)

    def search(self, filters: ReservationFilters | None = None) -> dict[str, list[EnvironmentReservation]]:
        """
        Searches environment reservations by filters, grouped by environment id.

        :param filters: the search criteria.
        :return: a map of matching reservations grouped by environment id.
        """
        result: dict[str, list[EnvironmentReservation]] = {}
        for reservation in self.searchReservations(filters):
            env = reservation.environment
            env_id = env.id if env and env.id else "unknown"
            result.setdefault(env_id, []).append(reservation)
        return result

    def hasReservation(self, environmentId: str, applicationId: str) -> bool:
        """
        Checks if the given application has a reservation on the given environment
        at the current time.

        :param environmentId: the environment identifier.
        :param applicationId: the application identifier.
        :return: True if a reservation exists at the current time.
        """
        now = datetime.now(timezone.utc)
        filters = ReservationFilters(
            environmentId=environmentId,
            applicationId=applicationId,
            from_=(now - timedelta(days=1)).isoformat(),
            to=(now + timedelta(days=1)).isoformat(),
        )
        for reservation in self.searchReservations(filters):
            start = self._parse_date(reservation.startDate)
            end = self._parse_date(reservation.endDate)
            if start is not None and start <= now and (end is None or end >= now):
                return True
        return False

    def nearestComingReservation(self, environmentId: str, applicationId: str) -> datetime | None:
        """
        Returns the start date of the nearest current or future reservation for the
        given application and environment.

        :param environmentId: the environment identifier.
        :param applicationId: the application identifier.
        :return: the start time of the nearest current/future reservation, or None.
        """
        now = datetime.now(timezone.utc)
        filters = ReservationFilters(
            environmentId=environmentId,
            applicationId=applicationId,
            from_=now.isoformat(),
            to=(now + timedelta(days=89)).isoformat(),
        )
        candidates: list[datetime] = []
        for reservation in self.searchReservations(filters):
            start = self._parse_date(reservation.startDate)
            end = self._parse_date(reservation.endDate)
            if start is None:
                continue
            if start <= now and (end is None or end >= now):
                return start
            if start > now:
                candidates.append(start)
        return min(candidates) if candidates else None

    @staticmethod
    def _parse_date(value: object) -> datetime | None:
        """Parses an ISO-8601 date string or epoch milliseconds into a datetime."""
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(value / 1000.0, tz=timezone.utc)
        try:
            text = str(value).replace("Z", "+00:00")
            parsed = datetime.fromisoformat(text)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed
        except (ValueError, TypeError):
            return None
