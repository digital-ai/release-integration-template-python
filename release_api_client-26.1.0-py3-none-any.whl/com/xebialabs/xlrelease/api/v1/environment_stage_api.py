from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.environment import (
    EnvironmentStage,
    EnvironmentStageFilters,
)


class EnvironmentStageApi:
    """Operations on environment stages."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the EnvironmentStageApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def createStage(self, stageForm: EnvironmentStage) -> EnvironmentStage:
        """
        Creates a new environment stage.

        :param stageForm: an EnvironmentStage (form) describing the new stage.
        :return: the created environment stage.
        """
        response = self.api.post(
            "/api/v1/environments/stages",
            json=stageForm.model_dump(exclude_none=True)
        )
        return EnvironmentStage.from_response(response)

    def getStageById(self, environmentStageId: str) -> EnvironmentStage:
        """
        Gets an environment stage by id.

        :param environmentStageId: the environment stage identifier.
        :return: the environment stage.
        """
        response = self.api.get(f"/api/v1/environments/stages/{environmentStageId}")
        return EnvironmentStage.from_response(response)

    def updateStage(self, environmentStageId: str, stageForm: EnvironmentStage) -> EnvironmentStage:
        """
        Updates an existing environment stage.

        :param environmentStageId: the environment stage identifier.
        :param stageForm: an EnvironmentStage (form) describing the new properties.
        :return: the updated environment stage.
        """
        response = self.api.put(
            f"/api/v1/environments/stages/{environmentStageId}",
            json=stageForm.model_dump(exclude_none=True)
        )
        return EnvironmentStage.from_response(response)

    def searchStages(self, filters: EnvironmentStageFilters | None = None) -> list[EnvironmentStage]:
        """
        Searches environment stages by filters.

        :param filters: the search criteria.
        :return: the list of matching environment stages.
        """
        body = filters.model_dump(exclude_none=True) if filters else {}
        response = self.api.post("/api/v1/environments/stages/search", json=body)
        return EnvironmentStage.from_response_to_list(response)

    def delete(self, environmentStageId: str) -> None:
        """
        Deletes an environment stage.

        :param environmentStageId: the environment stage identifier.
        """
        response = self.api.delete(f"/api/v1/environments/stages/{environmentStageId}")
        response.raise_for_status()

    # --- Convenience aliases matching the Jython script API ---

    def create(self, environmentStage: EnvironmentStage) -> EnvironmentStage:
        """
        Creates a new environment stage.

        :param environmentStage: an EnvironmentStage object describing the new stage.
        :return: the created environment stage.
        """
        return self.createStage(environmentStage)

    def getById(self, environmentStageId: str) -> EnvironmentStage:
        """
        Gets an environment stage by id.

        :param environmentStageId: the environment stage identifier.
        :return: the environment stage.
        """
        return self.getStageById(environmentStageId)

    def update(self, environmentStage: EnvironmentStage) -> EnvironmentStage:
        """
        Updates an existing environment stage.

        :param environmentStage: an EnvironmentStage object describing the new properties.
        :return: the updated environment stage.
        """
        if not environmentStage.id:
            raise ValueError("environmentStage.id must be set to update a stage")
        return self.updateStage(environmentStage.id, environmentStage)

    def search(self, filters: EnvironmentStageFilters | None = None) -> list[EnvironmentStage]:
        """
        Searches environment stages by filters.

        :param filters: the search criteria.
        :return: the list of matching environment stages.
        """
        return self.searchStages(filters)
