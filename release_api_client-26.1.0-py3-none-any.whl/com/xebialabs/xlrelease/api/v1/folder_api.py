from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.folder import Folder
from com.xebialabs.xlrelease.domain.forms import ReleasesFilters
from com.xebialabs.xlrelease.domain.release import Release
from com.xebialabs.xlrelease.domain.team import TeamView
from com.xebialabs.xlrelease.domain.variable import Variable


class FolderApi:
    """Operations on folders."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the FolderApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def listRoot(
            self,
            page: int | None = None,
            resultsPerPage: int | None = None,
            depth: int | None = None,
            permissions: bool | None = None
    ) -> list[Folder]:
        """
        Returns a list of folders from the root directory.

        :param page: the page of results to return. Defaults to 0 if None.
        :param resultsPerPage: the number of results per page. Defaults to 50 if None.
        :param depth: the depth to search for. Defaults to 1 if None.
        :param permissions: decorate folders with effective permissions. Defaults to False if None.
        :return: a list of folders.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if depth is not None:
            params["depth"] = depth
        if permissions is not None:
            params["permissions"] = permissions
        response = self.api.get("/api/v1/folders/list", params=params)
        return Folder.from_response_to_list(response)

    def list(
            self,
            parentId: str,
            page: int | None = None,
            resultsPerPage: int | None = None,
            depth: int | None = None,
            permissions: bool | None = None
    ) -> list[Folder]:
        """
        Lists the folders inside a given folder.

        :param parentId: the parent folder to retrieve from.
        :param page: the page of results to return. Defaults to 0.
        :param resultsPerPage: the number of results per page. Defaults to 50.
        :param depth: the depth to search for. Defaults to 1.
        :param permissions: decorate folders with effective permissions.
        :return: the list of folders beneath a given folder.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if depth is not None:
            params["depth"] = depth
        if permissions is not None:
            params["permissions"] = permissions
        response = self.api.get(f"/api/v1/folders/{parentId}/list", params=params)
        return Folder.from_response_to_list(response)

    def find(self, path: str, depth: int | None = None) -> Folder:
        """
        Finds a folder from a given path.

        :param path: the path for the folder to search on.
        :param depth: the depth to search for. Defaults to 1.
        :return: the folder found in the path.
        """
        params: dict[str, str | int] = {"byPath": path}
        if depth is not None:
            params["depth"] = depth
        response = self.api.get("/api/v1/folders/find", params=params)
        return Folder.from_response(response)

    def getFolder(self, folderId: str, depth: int | None = None) -> Folder:
        """
        Returns the specified folder.

        :param folderId: the id of the folder.
        :param depth: the depth to search for. Defaults to 1.
        :return: the specified folder.
        """
        params = {}
        if depth is not None:
            params["depth"] = depth
        response = self.api.get(f"/api/v1/folders/{folderId}", params=params)
        return Folder.from_response(response)

    def getTemplates(
            self,
            folderId: str,
            title: str | None = None,
            tags: list[str] | None = None,
            kind: str | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Returns the list of release or workflow templates for the given folder.

        :param folderId: the id of the folder.
        :param title: an optional search filter containing the title of the template.
        :param tags: an optional search filter containing list of template tags.
        :param kind: the kind of template. Default value is RELEASE.
        :param page: the page of results to return. Defaults to 0.
        :param resultsPerPage: the number of results per page. Defaults to 50.
        :return: the list of templates in the folder.
        """
        params = {}
        if title is not None:
            params["title"] = title
        if tags is not None:
            params["tag"] = tags
        if kind is not None:
            params["kind"] = kind
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get(f"/api/v1/folders/{folderId}/templates", params=params)
        return Release.from_response_to_list(response)

    def searchReleases(
            self,
            folderId: str,
            releasesFilters: ReleasesFilters | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Returns the releases started from this folder.

        :param folderId: the id of the folder.
        :param releasesFilters: releaseFilter to filter the release search.
        :param page: the page of results to return. Defaults to 0.
        :param resultsPerPage: the number of results per page. Defaults to 50.
        :return: the list of releases.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["numberbypage"] = resultsPerPage
        body = releasesFilters.model_dump(exclude_none=True) if releasesFilters else {}
        response = self.api.post(
            f"/api/v1/folders/{folderId}/releases",
            json=body,
            params=params
        )
        return Release.from_response_to_list(response)

    def moveTemplate(
            self,
            folderId: str,
            templateId: str,
            mergePermissions: bool | None = None
    ) -> None:
        """
        Move a template to another folder.

        :param folderId: the target folder the template will be moved to.
        :param templateId: the id of the template to be moved.
        :param mergePermissions: whether to merge permissions.
        """
        params = {}
        if mergePermissions is not None:
            params["mergePermissions"] = mergePermissions
        response = self.api.post(
            f"/api/v1/folders/{folderId}/templates/{templateId}",
            params=params
        )
        response.raise_for_status()

    def addFolder(self, parentId: str, folder: Folder) -> Folder:
        """
        Adds a new folder inside the specified folder.

        :param parentId: the id of the folder to create the folder in.
        :param folder: the folder to create.
        :return: the newly created folder.
        """
        body = folder.model_dump(exclude_none=True)
        body.setdefault("type", "xlrelease.Folder")
        if "id" not in body:
            import uuid
            body["id"] = f"folder_{uuid.uuid4().hex[:8]}"
        response = self.api.post(
            f"/api/v1/folders/{parentId}",
            json=body
        )
        return Folder.from_response(response)

    def delete(self, folderId: str) -> None:
        """
        Deletes the specified folder and all the contents inside.

        :param folderId: the id of the folder to delete.
        """
        response = self.api.delete(f"/api/v1/folders/{folderId}")
        response.raise_for_status()

    def move(self, folderId: str, newParentId: str) -> Folder:
        """
        Move a folder to another folder.

        :param folderId: the id of the folder to move.
        :param newParentId: the id of the parent folder the folder will be moved under.
        :return: the moved folder.
        """
        params = {"newParentId": newParentId}
        response = self.api.post(f"/api/v1/folders/{folderId}/move", params=params)
        return Folder.from_response(response)

    def rename(self, folderId: str, newName: str) -> None:
        """
        Rename a folder.

        :param folderId: the id of the folder to rename.
        :param newName: the new name of the folder.
        """
        params = {"newName": newName}
        response = self.api.post(f"/api/v1/folders/{folderId}/rename", params=params)
        response.raise_for_status()

    def getPermissions(self) -> list[str]:
        """
        Returns possible permissions.

        :return: list of permissions for folders, templates and releases.
        """
        response = self.api.get("/api/v1/folders/permissions")
        response.raise_for_status()
        return response.json()

    def getTeams(self, folderId: str) -> list[TeamView]:
        """
        Returns folder effective teams.

        :param folderId: the id of the folder.
        :return: list of effective teams.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/teams")
        return TeamView.from_response_to_list(response)

    def setTeams(self, folderId: str, teams: list[TeamView]) -> list[TeamView]:
        """
        Set teams of the folder.

        :param folderId: the identifier of the folder.
        :param teams: the teams to set.
        :return: a list of updated teams.
        """
        response = self.api.post(
            f"/api/v1/folders/{folderId}/teams",
            json=[t.model_dump(exclude_none=True) for t in teams]
        )
        return TeamView.from_response_to_list(response)

    def isFolderOwner(self, folderId: str) -> bool:
        """
        Returns whether the current user is an owner of the folder.

        :param folderId: the id of the folder.
        :return: True if the current user is a folder owner.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/folderOwner")
        response.raise_for_status()
        return response.json()

    def getTeam(self, folderId: str, teamId: str) -> TeamView:
        """
        Returns a team of the folder by its id.

        :param folderId: the id of the folder.
        :param teamId: the team identifier.
        :return: the team.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/{teamId}")
        return TeamView.from_response(response)

    def findTeam(self, folderId: str, teamName: str) -> TeamView:
        """
        Returns a team of the folder by its name.

        :param folderId: the id of the folder.
        :param teamName: the team name.
        :return: the team.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/teams/{teamName}")
        return TeamView.from_response(response)

    def getPath(self, folderId: str) -> str:
        """
        Returns the full path of the folder.

        :param folderId: the id of the folder.
        :return: the folder path.
        """
        folder = self.getFolder(folderId)
        return folder.path or folder.title or ""

    def getPathSegments(self, folderId: str) -> list[str]:
        """
        Returns the path of the folder, split into segments.

        :param folderId: the id of the folder.
        :return: the list of path segments.
        """
        path = self.getPath(folderId)
        return [segment for segment in path.split("/") if segment]

    def listVariables(self, folderId: str, folderOnly: bool = False) -> list[Variable]:
        """
        Returns folder variables list.

        :param folderId: the folder identifier.
        :param folderOnly: filter if you only want to get information from your folder.
        :return: variables list.
        """
        params = {"folderOnly": folderOnly}
        response = self.api.get(f"/api/v1/folders/{folderId}/variables", params=params)
        return Variable.from_response_to_list(response)

    def listVariableValues(self, folderId: str, folderOnly: bool = False) -> dict[str, str]:
        """
        Returns folder variables list with replaced variable values.

        :param folderId: the folder identifier.
        :param folderOnly: filter if you only want to get information from your folder.
        :return: a map of variable values.
        """
        params = {"folderOnly": folderOnly}
        response = self.api.get(f"/api/v1/folders/{folderId}/variableValues", params=params)
        response.raise_for_status()
        return response.json()

    def createVariable(self, folderId: str, variable: Variable) -> Variable:
        """
        Adds a folder variable.

        :param folderId: the folder identifier.
        :param variable: the folder variable to add.
        :return: the added folder variable.
        """
        response = self.api.post(
            f"/api/v1/folders/{folderId}/variables",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def getVariable(self, folderId: str, variableId: str) -> Variable:
        """
        Returns the folder variable for the given identifier.

        :param folderId: the folder identifier.
        :param variableId: the variable identifier.
        :return: the variable.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/{variableId}")
        return Variable.from_response(response)

    def updateVariable(self, folderId: str, variableId: str, variable: Variable) -> Variable:
        """
        Updates properties of a folder variable by its ID.

        :param folderId: the folder identifier.
        :param variableId: the variable identifier.
        :param variable: the variable to update.
        :return: the updated variable.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{variableId}",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def deleteVariable(self, folderId: str, variableId: str) -> None:
        """
        Deletes a folder variable.

        :param folderId: the folder identifier.
        :param variableId: the variable identifier.
        """
        response = self.api.delete(f"/api/v1/folders/{folderId}/{variableId}")
        response.raise_for_status()

    def getVariablePossibleValues(self, folderId: str, variableId: str) -> list:
        """
        Returns possible values for the variable with the given identifier.

        :param folderId: the folder identifier.
        :param variableId: the variable identifier.
        :return: possible values for the variable.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/{variableId}/possibleValues")
        response.raise_for_status()
        return response.json()

    def createTeam(
            self,
            folderId: str,
            name: str,
            principals: list[str] | None = None,
            roles: list[str] | None = None,
            permissions: list[str] | None = None
    ) -> str:
        """
        Creates a team in a folder.

        :param folderId: the folder identifier.
        :param name: the team name.
        :param principals: the list of principals.
        :param roles: the list of roles.
        :param permissions: the list of permissions.
        :return: the team ID.
        """
        body = {"name": name}
        if principals is not None:
            body["principals"] = principals
        if roles is not None:
            body["roles"] = roles
        if permissions is not None:
            body["permissions"] = permissions
        response = self.api.post(f"/api/v1/folders/{folderId}/create-team", json=body)
        response.raise_for_status()
        return response.text

    def deleteTeamByName(self, folderId: str, teamName: str) -> None:
        """
        Deletes a team by name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        """
        response = self.api.delete(f"/api/v1/folders/{folderId}/teams/{teamName}")
        response.raise_for_status()

    def deleteTeamById(self, folderId: str, teamId: str) -> None:
        """
        Deletes a team by ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        """
        response = self.api.delete(f"/api/v1/folders/{folderId}/{teamId}")
        response.raise_for_status()

    def addPrincipalsToTeamById(self, folderId: str, teamId: str, principalNames: list[str]) -> None:
        """
        Adds principals to a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/add-principals",
            json=principalNames
        )
        response.raise_for_status()

    def addPrincipalsToTeamByName(self, folderId: str, teamName: str, principalNames: list[str]) -> None:
        """
        Adds principals to a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/add-principals",
            json=principalNames
        )
        response.raise_for_status()

    def removePrincipalsFromTeamById(self, folderId: str, teamId: str, principalNames: list[str]) -> None:
        """
        Removes principals from a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/remove-principals",
            json=principalNames
        )
        response.raise_for_status()

    def removePrincipalsFromTeamByName(self, folderId: str, teamName: str, principalNames: list[str]) -> None:
        """
        Removes principals from a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/remove-principals",
            json=principalNames
        )
        response.raise_for_status()

    def addRoleNamesToTeamById(self, folderId: str, teamId: str, roleNames: list[str]) -> None:
        """
        Adds role names to a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param roleNames: the list of role names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/add-roles",
            json=roleNames
        )
        response.raise_for_status()

    def addRoleNamesToTeamByName(self, folderId: str, teamName: str, roleNames: list[str]) -> None:
        """
        Adds role names to a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param roleNames: the list of role names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/add-roles",
            json=roleNames
        )
        response.raise_for_status()

    def removeRoleNamesFromTeamById(self, folderId: str, teamId: str, roleNames: list[str]) -> None:
        """
        Removes role names from a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param roleNames: the list of role names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/remove-roles",
            json=roleNames
        )
        response.raise_for_status()

    def removeRoleNamesFromTeamByName(self, folderId: str, teamName: str, roleNames: list[str]) -> None:
        """
        Removes role names from a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param roleNames: the list of role names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/remove-roles",
            json=roleNames
        )
        response.raise_for_status()

    def addPermissionsToTeamById(self, folderId: str, teamId: str, permissions: list[str]) -> None:
        """
        Adds permissions to a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param permissions: the list of permissions.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/add-permissions",
            json=permissions
        )
        response.raise_for_status()

    def addPermissionsToTeamByName(self, folderId: str, teamName: str, permissions: list[str]) -> None:
        """
        Adds permissions to a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param permissions: the list of permissions.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/add-permissions",
            json=permissions
        )
        response.raise_for_status()

    def removePermissionsFromTeamById(self, folderId: str, teamId: str, permissions: list[str]) -> None:
        """
        Removes permissions from a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param permissions: the list of permissions.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/remove-permissions",
            json=permissions
        )
        response.raise_for_status()

    def removePermissionsFromTeamByName(self, folderId: str, teamName: str, permissions: list[str]) -> None:
        """
        Removes permissions from a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param permissions: the list of permissions.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/remove-permissions",
            json=permissions
        )
        response.raise_for_status()
