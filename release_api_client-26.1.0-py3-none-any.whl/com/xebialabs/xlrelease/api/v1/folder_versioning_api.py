from __future__ import annotations

from typing import Any

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.versioning import (
    CreateVersionForm,
    FoldersWithAppliedVersionInfo,
    FolderVersioningSettings,
    GitBranch,
    ValidationReport,
    ValidationReportMessage,
    VersionComparisonView,
    VersionInfo,
    VersioningStyle,
    VersionsView,
)


class FolderVersioningApi:
    """
    Operations to store and synchronize folder contents - templates, workflows,
    connections, variables, and more - as YAML files in Git for version tracking.
    """

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the FolderVersioningApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getSettings(self, folderId: str) -> FolderVersioningSettings:
        """
        Retrieves the Git versioning settings for the specified folder.

        :param folderId: the unique identifier of the folder.
        :return: the current versioning settings associated with the folder.
        """
        response = self.api.get(f"/api/v1/version-control/{folderId}/")
        return FolderVersioningSettings.from_response(response)

    def updateSettings(self, folderId: str, config: FolderVersioningSettings) -> FolderVersioningSettings:
        """
        Updates the Git versioning settings for the specified folder.

        :param folderId: the unique identifier of the folder.
        :param config: the new versioning configuration to apply.
        :return: the updated versioning settings for the folder.
        """
        response = self.api.put(
            f"/api/v1/version-control/{folderId}/",
            json=config.model_dump(exclude_none=True)
        )
        return FolderVersioningSettings.from_response(response)

    def deleteSettings(self, folderId: str) -> None:
        """
        Deletes the Git versioning settings and versioned history for the specified folder.

        :param folderId: the unique identifier of the folder.
        """
        response = self.api.delete(f"/api/v1/version-control/{folderId}/")
        response.raise_for_status()

    def getVersions(self, folderId: str, fetchChanges: bool | None = None) -> VersionsView:
        """
        Retrieves all versions associated with the specified folder.

        :param folderId: the unique identifier of the folder.
        :param fetchChanges: whether to fetch changes from the repository before returning. Defaults to False.
        :return: the versions for the specified folder.
        """
        params = {}
        if fetchChanges is not None:
            params["fetchChanges"] = fetchChanges
        response = self.api.get(f"/api/v1/version-control/{folderId}/versions", params=params)
        return VersionsView.from_response(response)

    def getAllBranches(self, folderId: str, configId: str | None = None) -> list[GitBranch]:
        """
        Retrieves all branches associated with the specified folder.

        :param folderId: the unique identifier of the folder.
        :param configId: the configuration ID to filter branches (optional).
        :return: a list of branches for the specified folder.
        """
        params = {}
        if configId is not None:
            params["configId"] = configId
        response = self.api.get(f"/api/v1/version-control/{folderId}/branches", params=params)
        return GitBranch.from_response_to_list(response)

    def createVersion(
            self,
            folderId: str,
            versionForm: CreateVersionForm | str,
            description: str | None = None
    ) -> VersionInfo:
        """
        Creates a new version for the specified folder.

        Can be called as ``createVersion(folderId, versionForm)`` or
        ``createVersion(folderId, versionName, description)``.

        :param folderId: the unique identifier of the folder.
        :param versionForm: a CreateVersionForm, or the version name.
        :param description: a brief description of the version (when a name is supplied).
        :return: information about the newly created version.
        """
        if isinstance(versionForm, CreateVersionForm):
            body = versionForm.model_dump(exclude_none=True)
        else:
            body = CreateVersionForm(versionName=versionForm, description=description).model_dump(exclude_none=True)
        response = self.api.post(f"/api/v1/version-control/{folderId}/versions", json=body)
        return VersionInfo.from_response(response)

    def applyVersion(self, folderId: str, version: str) -> ValidationReport:
        """
        Applies the specified version to the given folder.

        :param folderId: the unique identifier of the folder.
        :param version: the version to apply.
        :return: a validation report for the applied version.
        """
        response = self.api.post(f"/api/v1/version-control/{folderId}/versions/{version}/apply")
        return ValidationReport.from_response(response)

    def getVersionedFileNames(self, folderId: str, version: str) -> list[str]:
        """
        Returns the list of file names associated with the specified version of a folder.

        :param folderId: the unique identifier of the folder.
        :param version: the version of the folder.
        :return: a list of file names present in the specified version.
        """
        response = self.api.get(
            f"/api/v1/version-control/{folderId}/versions/{version}/getVersionedFileNames"
        )
        response.raise_for_status()
        return response.json()

    def getCurrentVersionableFileNames(self, folderId: str) -> list[str]:
        """
        Retrieves the list of file names that are currently versionable in the folder.

        :param folderId: the unique identifier of the folder.
        :return: a list of currently versionable file names.
        """
        response = self.api.get(f"/api/v1/version-control/{folderId}/getVersionableFileNames")
        response.raise_for_status()
        return response.json()

    def deleteLocalRepo(self, folderId: str, clusterWide: bool | None = None) -> None:
        """
        Deletes the local Git repository for the specified folder.

        :param folderId: the unique identifier of the folder.
        :param clusterWide: whether to delete the repo cluster-wide. Defaults to False.
        """
        params = {}
        if clusterWide is not None:
            params["clusterWide"] = clusterWide
        response = self.api.delete(
            f"/api/v1/version-control/{folderId}/delete-local-repo",
            params=params
        )
        response.raise_for_status()

    def resetLocalRepo(self, folderId: str, clusterWide: bool | None = None) -> None:
        """
        Resets the local Git repository for the specified folder.

        :param folderId: the unique identifier of the folder.
        :param clusterWide: whether to reset the repo cluster-wide. Defaults to False.
        """
        params = {}
        if clusterWide is not None:
            params["clusterWide"] = clusterWide
        response = self.api.put(
            f"/api/v1/version-control/{folderId}/reset-local-repo",
            params=params
        )
        response.raise_for_status()

    def validateCurrent(self, folderId: str) -> ValidationReport:
        """
        Validates the current state of the specified folder.

        :param folderId: the unique identifier of the folder.
        :return: a validation report.
        """
        response = self.api.get(f"/api/v1/version-control/{folderId}/validate")
        return ValidationReport.from_response(response)

    def getValidationMessages(self, folderId: str) -> ValidationReport:
        """
        Retrieves the validation messages for the currently applied version.

        :param folderId: the unique identifier of the folder.
        :return: a validation report.
        """
        response = self.api.get(f"/api/v1/version-control/{folderId}/validation-messages")
        return ValidationReport.from_response(response)

    def setValidationMessages(self, folderId: str, validationReport: ValidationReport) -> None:
        """
        Sets the validation messages for the specified folder.

        :param folderId: the unique identifier of the folder.
        :param validationReport: the validation messages to associate with the folder.
        """
        response = self.api.put(
            f"/api/v1/version-control/{folderId}/validation-messages",
            json=validationReport.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def getValidationMessage(self, folderId: str, messageId: str) -> ValidationReportMessage:
        """
        Retrieves a specific validation message for the given folder and message ID.

        :param folderId: the unique identifier of the folder.
        :param messageId: the unique identifier of the validation message.
        :return: the validation report message.
        """
        response = self.api.get(f"/api/v1/version-control/{folderId}/message/{messageId}/")
        return ValidationReportMessage.from_response(response)

    def setValidationMessagesStatus(
            self,
            folderId: str,
            messageId: str,
            validationMessage: ValidationReportMessage
    ) -> None:
        """
        Updates the status of a specific validation message.

        :param folderId: the unique identifier of the folder.
        :param messageId: the unique identifier of the validation message.
        :param validationMessage: the updated validation report message.
        """
        response = self.api.put(
            f"/api/v1/version-control/{folderId}/message/{messageId}/update",
            json=validationMessage.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def clearSecrets(self, folderId: str) -> None:
        """
        Clears the stored secrets for the specified folder.

        :param folderId: the unique identifier of the folder.
        """
        response = self.api.delete(f"/api/v1/version-control/{folderId}/clear-secrets")
        response.raise_for_status()

    def getVersioningStyles(self) -> list[VersioningStyle]:
        """
        Retrieves the list of available versioning styles.

        :return: a list of supported versioning styles.
        """
        response = self.api.get("/api/v1/version-control/styles")
        return VersioningStyle.from_response_to_list(response)

    def compareFileVersions(
            self,
            folderId: str,
            fileName: str,
            leftVersion: str | None = None,
            rightVersion: str | None = None
    ) -> str:
        """
        Compares two versions of a specified file within a given folder.

        :param folderId: the unique identifier of the folder.
        :param fileName: the name of the file to compare.
        :param leftVersion: the source (left) version. Defaults to the current version.
        :param rightVersion: the target (right) version. Defaults to the current version.
        :return: the comparison results identifying the differences.
        """
        params: dict[str, Any] = {"fileName": fileName}
        if leftVersion is not None:
            params["leftVersion"] = leftVersion
        if rightVersion is not None:
            params["rightVersion"] = rightVersion
        response = self.api.get(f"/api/v1/version-control/{folderId}/compare-file", params=params)
        response.raise_for_status()
        return response.text

    def compareFileVersionWithCurrent(self, folderId: str, fileName: str, version: str) -> str:
        """
        Compares a specified version of a file with the current state of the folder.

        :param folderId: the unique identifier of the folder.
        :param fileName: the name of the file to compare.
        :param version: the version to compare against the current version.
        :return: the comparison results identifying the differences.
        """
        return self.compareFileVersions(folderId, fileName, version, None)

    def compareVersions(
            self,
            folderId: str,
            leftVersion: str | None = None,
            rightVersion: str | None = None
    ) -> VersionComparisonView:
        """
        Compares two versions for a specified folder.

        :param folderId: the unique identifier of the folder.
        :param leftVersion: the source (left) version. Defaults to the current version.
        :param rightVersion: the target (right) version. Defaults to the current version.
        :return: a comparison view identifying the differences.
        """
        params: dict[str, Any] = {}
        if leftVersion is not None:
            params["leftVersion"] = leftVersion
        if rightVersion is not None:
            params["rightVersion"] = rightVersion
        response = self.api.get(f"/api/v1/version-control/{folderId}/compare-versions", params=params)
        return VersionComparisonView.from_response(response)

    def compareVersionWithCurrent(self, folderId: str, version: str) -> VersionComparisonView:
        """
        Compares a specified version with the current version of the folder.

        :param folderId: the unique identifier of the folder.
        :param version: the version to compare against the current version.
        :return: a comparison view identifying the differences.
        """
        return self.compareVersions(folderId, version, None)

    def getVersionedFolderInfo(self) -> list[FoldersWithAppliedVersionInfo]:
        """
        Retrieves a list of all folders along with their currently applied version information.

        :return: a list of folders with their applied version details.
        """
        response = self.api.get("/api/v1/version-control/all-folders-applied-version")
        return FoldersWithAppliedVersionInfo.from_response_to_list(response)
