from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient


class PermissionsApi:
    """Operations on permissions."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the PermissionsApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getGlobalPermissions(self) -> list[str]:
        """
        Returns global permissions.

        :return: a list of global permissions.
        """
        response = self.api.get("/api/v1/global-permissions")
        response.raise_for_status()
        return response.json()
