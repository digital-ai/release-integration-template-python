from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.phase import Phase
from com.xebialabs.xlrelease.domain.task import Task


class PhaseApi:
    """Operations on phases."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the PhaseApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getPhase(self, phaseId: str) -> Phase:
        """
        Returns the phase for the given identifier.

        :param phaseId: the phase identifier.
        :return: the phase.
        """
        response = self.api.get(f"/api/v1/phases/{phaseId}")
        return Phase.from_response(response)

    def updatePhase(self, phaseId: str, phase: Phase) -> Phase:
        """
        Updates the properties of a phase.

        :param phaseId: the phase identifier.
        :param phase: new contents of the phase.
        :return: the updated phase.
        """
        response = self.api.put(
            f"/api/v1/phases/{phaseId}",
            json=phase.model_dump(exclude_none=True)
        )
        return Phase.from_response(response)

    def addTask(
            self,
            containerId: str,
            task: Task,
            position: int | None = None
    ) -> Task:
        """
        Adds a task to a phase or to a group task. If no position is specified,
        then task is added to the end of the phase.

        :param containerId: the phase or group task identifier.
        :param task: the task to add.
        :param position: the position in the phase (0-based). If left empty, then
            task will be added to the end of the phase.
        :return: the added task.
        """
        params = {}
        if position is not None:
            params["position"] = position
        body = task.model_dump(exclude_none=True)
        body.setdefault("type", "xlrelease.Task")
        if "id" not in body:
            import uuid
            body["id"] = f"task_{uuid.uuid4().hex[:8]}"
        response = self.api.post(
            f"/api/v1/phases/{containerId}/tasks",
            json=body,
            params=params
        )
        return Task.from_response(response)

    def searchPhasesByTitle(
            self,
            phaseTitle: str,
            releaseId: str
    ) -> list[Phase]:
        """
        Search phases in a release by title.

        :param phaseTitle: the phase title.
        :param releaseId: the release identifier.
        :return: a list of phases that match.
        """
        params = {"phaseTitle": phaseTitle, "releaseId": releaseId}
        response = self.api.get("/api/v1/phases/byTitle", params=params)
        return Phase.from_response_to_list(response)

    def searchPhases(
            self,
            releaseId: str,
            phaseTitle: str | None = None,
            phaseVersion: str | None = None
    ) -> list[Phase]:
        """
        Search phases within a release.

        ReleaseId is required, all other parameters are optional. Providing
        optional parameters will narrow down the search.

        :param releaseId: the release identifier.
        :param phaseTitle: (part of) the phase title. If not provided, all phases are returned.
        :param phaseVersion: phase version (LATEST, ORIGINAL, or ALL). If not provided,
            no filtering will be applied.
        :return: a list of phases that match.
        """
        params: dict[str, str] = {"releaseId": releaseId}
        if phaseTitle is not None:
            params["phaseTitle"] = phaseTitle
        if phaseVersion is not None:
            params["phaseVersion"] = phaseVersion
        response = self.api.get("/api/v1/phases/search", params=params)
        return Phase.from_response_to_list(response)

    def addPhase(
            self,
            releaseId: str,
            phase: Phase,
            position: int | None = None
    ) -> Phase:
        """
        Adds a phase to a release. If no position is specified, then the phase is
        added as the last phase. All nested configuration items (e.g. tasks) will be
        removed from the provided phase.

        :param releaseId: the identifier of a template/release.
        :param phase: the phase to add.
        :param position: the position in the template (0-based). If left empty, then
            the phase will be the last phase in the template.
        :return: the added Phase object.
        """
        params = {}
        if position is not None:
            params["position"] = position
        body = phase.model_dump(exclude_none=True)
        body.setdefault("type", "xlrelease.Phase")
        if "id" not in body:
            import uuid
            body["id"] = f"phase_{uuid.uuid4().hex[:8]}"
        response = self.api.post(
            f"/api/v1/phases/{releaseId}/phase",
            json=body,
            params=params
        )
        return Phase.from_response(response)

    def copyPhase(
            self,
            phaseId: str,
            targetPosition: int
    ) -> Phase:
        """
        Copy a phase in a release.

        :param phaseId: the phase id to copy.
        :param targetPosition: the position where to copy the phase to within a release.
        :return: the copy of the Phase object.
        """
        params = {"targetPosition": targetPosition}
        response = self.api.post(
            f"/api/v1/phases/{phaseId}/copy",
            params=params
        )
        return Phase.from_response(response)

    def newPhase(self, title: str | None = None) -> Phase:
        """
        Factory method to create a new instance of a Phase object.

        :param title: the title of the phase. If not provided, a phase with no title is created.
        :return: the phase object.
        """
        phase = Phase(title=title)
        return phase

    def deletePhase(self, phaseId: str) -> None:
        """
        Deletes the phase with the given ID.

        :param phaseId: the phase identifier.
        """
        response = self.api.delete(f"/api/v1/phases/{phaseId}")
        response.raise_for_status()
