from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.forms import ReleasesFilters, VariableOrValue
from com.xebialabs.xlrelease.domain.phase import Phase
from com.xebialabs.xlrelease.domain.release import BasicReleaseView, Release
from com.xebialabs.xlrelease.domain.task import Task
from com.xebialabs.xlrelease.domain.team import TeamView
from com.xebialabs.xlrelease.domain.variable import Variable


class ReleaseApi:
    """Operations on releases."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the ReleaseApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getReleases(
            self,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Returns the list of planned or active releases that are visible to the current user.

        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default and maximum value is 100.
        :return: a list of releases.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get("/api/v1/releases", params=params)
        return Release.from_response_to_list(response)

    def getRelease(self, releaseId: str, withRoleIds: bool | None = None) -> Release:
        """
        Returns the release with the given ID.

        :param releaseId: the identifier of the release.
        :param withRoleIds: if true, includes role IDs in the response.
        :return: the release.
        """
        params = {}
        if withRoleIds is not None:
            params["roleIds"] = withRoleIds
        response = self.api.get(f"/api/v1/releases/{releaseId}", params=params)
        return Release.from_response(response)

    def getArchivedRelease(self, releaseId: str, withRoleIds: bool | None = None) -> Release:
        """
        Returns the archived release for the given ID.

        :param releaseId: the identifier of the release.
        :param withRoleIds: if true, includes role IDs in the response.
        :return: the release.
        """
        params = {}
        if withRoleIds is not None:
            params["roleIds"] = withRoleIds
        response = self.api.get(f"/api/v1/releases/archived/{releaseId}", params=params)
        return Release.from_response(response)

    def getAttachment(self, attachmentId: str) -> bytes:
        """
        Downloads an attachment by its ID.

        :param attachmentId: the identifier of the attachment.
        :return: the attachment content as bytes.
        """
        response = self.api.get(
            f"/api/v1/releases/attachments/{attachmentId}",
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response.content

    def downloadAttachment(self, attachmentId: str) -> bytes:
        """
        Downloads an attachment by its ID.

        :param attachmentId: the identifier of the attachment.
        :return: the attachment content as bytes.
        """
        return self.getAttachment(attachmentId)

    def getActiveTasks(self, releaseId: str) -> list[Task]:
        """
        Returns the active tasks in a release.

        :param releaseId: the identifier of the release.
        :return: a list of active tasks.
        """
        response = self.api.get(f"/api/v1/releases/{releaseId}/active-tasks")
        return Task.from_response_to_list(response)

    def start(self, releaseId: str) -> Release:
        """
        Starts a planned release.

        :param releaseId: the release identifier.
        :return: the started release.
        """
        response = self.api.post(f"/api/v1/releases/{releaseId}/start")
        return Release.from_response(response)

    def updateRelease(self, releaseId: str, release: Release) -> Release:
        """
        Updates the properties of a release.

        :param releaseId: the identifier of the release.
        :param release: new contents of the release.
        :return: the updated release.
        """
        response = self.api.put(
            f"/api/v1/releases/{releaseId}",
            json=release.model_dump(exclude_none=True)
        )
        return Release.from_response(response)

    def delete(self, releaseId: str) -> None:
        """
        Deletes a release. The release MUST be in a final state (complete or aborted).

        :param releaseId: the identifier of the release.
        """
        response = self.api.delete(f"/api/v1/releases/{releaseId}")
        response.raise_for_status()

    def abort(self, releaseId: str, abortComment: str | None = None) -> Release:
        """
        Aborts a release.

        :param releaseId: the identifier of the release.
        :param abortComment: the comment of the abort.
        :return: the aborted release.
        """
        body = {}
        if abortComment is not None:
            body["abortComment"] = abortComment
        response = self.api.post(f"/api/v1/releases/{releaseId}/abort", json=body)
        return Release.from_response(response)

    def searchReleasesByTitle(self, releaseTitle: str) -> list[Release]:
        """
        Search releases by given title (exact match).

        :param releaseTitle: the title of the release.
        :return: a list of releases.
        """
        params = {"releaseTitle": releaseTitle}
        response = self.api.get("/api/v1/releases/byTitle", params=params)
        return Release.from_response_to_list(response)

    def searchReleasesOverview(
            self,
            releasesFilters: ReleasesFilters,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[BasicReleaseView]:
        """
        Searches releases overview by filters.

        :param releasesFilters: the search criteria.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default and maximum value is 100.
        :return: the list of matching release overviews.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.post(
            "/api/v1/releases/search/overview",
            json=releasesFilters.model_dump(exclude_none=True),
            params=params
        )
        return BasicReleaseView.from_response_to_list(response)

    def searchReleases(
            self,
            releasesFilters: ReleasesFilters,
            page: int | None = None,
            resultsPerPage: int | None = None,
            pageIsOffset: bool | None = None
    ) -> list[Release]:
        """
        Searches releases by filters.

        :param releasesFilters: the search criteria.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default and maximum value is 100.
        :param pageIsOffset: if true, page is used as an offset. Default is false.
        :return: the list of matching releases.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if pageIsOffset is not None:
            params["pageIsOffset"] = pageIsOffset
        response = self.api.post(
            "/api/v1/releases/search",
            json=releasesFilters.model_dump(exclude_none=True),
            params=params
        )
        return Release.from_response_to_list(response)

    def countReleases(self, releasesFilters: ReleasesFilters) -> dict:
        """
        Counts the releases matching the given filters.

        :param releasesFilters: the search criteria.
        :return: the release count results.
        """
        response = self.api.post(
            "/api/v1/releases/count",
            json=releasesFilters.model_dump(exclude_none=True)
        )
        response.raise_for_status()
        return response.json()

    def fullSearchReleases(
            self,
            releasesFilters: ReleasesFilters,
            page: int | None = None,
            archivePage: int | None = None,
            resultsPerPage: int | None = None,
            archiveResultsPerPage: int | None = None
    ) -> dict:
        """
        Searches releases across both the active and archive databases.

        :param releasesFilters: the search criteria.
        :param page: the next page to query in the active database.
        :param archivePage: the next page to query in the archive database.
        :param resultsPerPage: the number of releases per page in the active database.
        :param archiveResultsPerPage: the number of releases per page in the archive database.
        :return: the full search results.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if archivePage is not None:
            params["archivePage"] = archivePage
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if archiveResultsPerPage is not None:
            params["archiveResultsPerPage"] = archiveResultsPerPage
        response = self.api.post(
            "/api/v1/releases/fullSearch",
            json=releasesFilters.model_dump(exclude_none=True),
            params=params
        )
        response.raise_for_status()
        return response.json()

    def getVariables(self, releaseId: str) -> list[Variable]:
        """
        Get release variables.

        :param releaseId: the identifier of the release.
        :return: a list of variables.
        """
        response = self.api.get(f"/api/v1/releases/{releaseId}/variables")
        return Variable.from_response_to_list(response)

    def getVariableValues(self, releaseId: str) -> dict[str, str]:
        """
        Get release variable values.

        :param releaseId: the identifier of the release.
        :return: a map of variable values.
        """
        response = self.api.get(f"/api/v1/releases/{releaseId}/variableValues")
        response.raise_for_status()
        return response.json()

    def getVariable(self, variableId: str) -> Variable:
        """
        Returns the variable for the given identifier.

        :param variableId: the variable identifier.
        :return: the variable.
        """
        response = self.api.get(f"/api/v1/releases/{variableId}")
        return Variable.from_response(response)

    def getVariablePossibleValues(self, variableId: str) -> list:
        """
        Returns possible values for the variable with the given identifier.

        :param variableId: the variable identifier.
        :return: possible values for the variable.
        """
        response = self.api.get(f"/api/v1/releases/{variableId}/possibleValues")
        response.raise_for_status()
        return response.json()

    def isVariableUsed(self, variableId: str) -> bool:
        """
        Returns true if variable with the given identifier is used in the release.

        :param variableId: the variable ID.
        :return: true if the variable is used.
        """
        response = self.api.get(f"/api/v1/releases/{variableId}/used")
        response.raise_for_status()
        return response.json()

    def replaceVariable(self, variableId: str, variableOrValue: VariableOrValue) -> None:
        """
        Replace variable occurrences with the given replacement.

        :param variableId: the variable ID.
        :param variableOrValue: an object with a variable or value replacing the initial variable.
        """
        response = self.api.post(
            f"/api/v1/releases/{variableId}/replace",
            json=variableOrValue.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def deleteVariable(self, variableId: str) -> None:
        """
        Delete variable from release.

        :param variableId: the variable ID.
        """
        response = self.api.delete(f"/api/v1/releases/{variableId}")
        response.raise_for_status()

    def createVariable(self, releaseId: str, variable: Variable) -> Variable:
        """
        Create new variable.

        :param releaseId: the identifier of the release.
        :param variable: the variable to create.
        :return: created variable.
        """
        response = self.api.post(
            f"/api/v1/releases/{releaseId}/variables",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def updateVariables(self, releaseId: str, variables: list[Variable]) -> list[Variable]:
        """
        Update the list of variables in a release.

        :param releaseId: the identifier of the release.
        :param variables: the variable list to update.
        :return: updated variables.
        """
        response = self.api.put(
            f"/api/v1/releases/{releaseId}/variables",
            json=[v.model_dump(exclude_none=True) for v in variables]
        )
        return Variable.from_response_to_list(response)

    def updateVariable(self, variableId: str, variable: Variable) -> Variable:
        """
        Updates the properties of a variable.

        :param variableId: the variable identifier.
        :param variable: new contents of the variable.
        :return: the updated variable.
        """
        response = self.api.put(
            f"/api/v1/releases/{variableId}",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def getPermissions(self) -> list[str]:
        """
        Returns possible permissions.

        :return: list of permissions for releases.
        """
        response = self.api.get("/api/v1/releases/permissions")
        response.raise_for_status()
        return response.json()

    def getTeams(self, releaseId: str) -> list[TeamView]:
        """
        Returns effective teams of the release.

        :param releaseId: the identifier of the release.
        :return: a list of effective teams.
        """
        response = self.api.get(f"/api/v1/releases/{releaseId}/teams")
        return TeamView.from_response_to_list(response)

    def setTeams(self, releaseId: str, teams: list[TeamView]) -> list[TeamView]:
        """
        Sets teams of the release.

        :param releaseId: the identifier of the release.
        :param teams: the teams to set.
        :return: a list of updated teams.
        """
        response = self.api.post(
            f"/api/v1/releases/{releaseId}/teams",
            json=[t.model_dump(exclude_none=True) for t in teams]
        )
        return TeamView.from_response_to_list(response)

    def resume(self, releaseId: str) -> Release:
        """
        Resumes a release that has been paused as part of a restart phases operation.

        :param releaseId: the identifier of the release.
        :return: the release.
        """
        response = self.api.post(f"/api/v1/releases/{releaseId}/resume")
        return Release.from_response(response)

    def restartPhases(
            self,
            releaseId: str,
            fromPhaseId: str | None = None,
            fromTaskId: str | None = None,
            phaseVersion: str | None = None,
            resume: bool | None = None
    ) -> Release:
        """
        Restarts the release from a given phase and task.

        :param releaseId: the identifier of the release.
        :param fromPhaseId: the identifier of the phase to restart from.
        :param fromTaskId: the identifier of the task to restart from.
        :param phaseVersion: which version of the phase should be copied (LATEST, ORIGINAL, ALL).
        :param resume: if true resumes the paused release immediately.
        :return: the release.
        """
        params = {}
        if fromPhaseId is not None:
            params["fromPhaseId"] = fromPhaseId
        if fromTaskId is not None:
            params["fromTaskId"] = fromTaskId
        if phaseVersion is not None:
            params["phaseVersion"] = phaseVersion
        if resume is not None:
            params["resume"] = resume
        response = self.api.post(f"/api/v1/releases/{releaseId}/restart", params=params)
        return Release.from_response(response)

    def restartPhase(
            self,
            release: Release,
            phase: Phase | None = None,
            task: Task | None = None,
            phaseVersion: str | None = None,
            resumeRelease: bool | None = None
    ) -> Release:
        """
        Restart the release from a given phase and task.

        This is a convenience method that accepts domain objects instead of string IDs.
        It covers the following Java API overloads:
        - restartPhase(Release release)
        - restartPhase(Release release, boolean resumeRelease)
        - restartPhase(Release release, Phase phase)
        - restartPhase(Release release, Phase phase, PhaseVersion phaseVersion)
        - restartPhase(Release release, Phase phase, Task task)
        - restartPhase(Release release, Phase phase, Task task, PhaseVersion phaseVersion)
        - restartPhase(Release release, Phase phase, Task task, PhaseVersion phaseVersion, boolean resumeRelease)

        :param release: the release to restart.
        :param phase: the phase to restart from. If None, restarts from the current phase.
        :param task: the task to restart from.
        :param phaseVersion: which version of the phase should be copied (LATEST, ORIGINAL, ALL).
        :param resumeRelease: if true resumes the paused release immediately.
        :return: the release.
        """
        return self.restartPhases(
            releaseId=release.id,
            fromPhaseId=phase.id if phase is not None else None,
            fromTaskId=task.id if task is not None else None,
            phaseVersion=phaseVersion,
            resume=resumeRelease
        )
