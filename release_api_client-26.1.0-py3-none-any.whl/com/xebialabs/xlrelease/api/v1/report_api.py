from __future__ import annotations

from typing import Any

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.reporting import (
    FacetFilters,
    TaskReportingRecord,
)


class ReportApi:
    """Operations on reports."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the ReportApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getRecordsForRelease(self, releaseId: str) -> list[TaskReportingRecord]:
        """
        Returns the list of reporting records associated with a release.

        :param releaseId: the identifier of the release.
        :return: the list of reporting records.
        """
        response = self.api.get(f"/api/v1/reports/records/{releaseId}")
        return TaskReportingRecord.from_response_to_list(response)

    def getRecordsForTask(self, taskId: str) -> list[TaskReportingRecord]:
        """
        Returns the list of reporting records associated with a task.

        :param taskId: the identifier of the task.
        :return: the list of reporting records.
        """
        response = self.api.get(f"/api/v1/reports/records/{taskId}")
        return TaskReportingRecord.from_response_to_list(response)

    def searchRecords(self, facetFilters: FacetFilters | None = None) -> list[TaskReportingRecord]:
        """
        Searches reporting records.

        :param facetFilters: the search criteria.
        :return: the list of matching reporting records.
        """
        body = facetFilters.model_dump(exclude_none=True) if facetFilters else {}
        response = self.api.post("/api/v1/reports/records/search", json=body)
        return TaskReportingRecord.from_response_to_list(response)

    def downloadReleaseReport(self, reportType: str, releaseId: str) -> Any:
        """
        Downloads the single-release report by type.

        The report is delivered as a binary file (e.g. an Excel ``.xlsx`` for
        ``xlrelease.ReleaseAuditExcelReport``), so the request must accept a
        binary response rather than the client's default ``application/json``.

        :param reportType: the type of report (e.g. ``xlrelease.ReleaseAuditExcelReport``).
        :param releaseId: the identifier of the release.
        :return: the raw HTTP response containing the report file.
        """
        response = self.api.get(
            f"/api/v1/reports/download/{reportType}/{releaseId}",
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response

    def getReleaseReport(self, reportType: str, releaseId: str) -> bytes:
        """
        Returns the single-release report file by type.

        :param reportType: the type of report.
        :param releaseId: the identifier of the release.
        :return: the report file content as bytes.
        """
        response = self.downloadReleaseReport(reportType, releaseId)
        return response.content
