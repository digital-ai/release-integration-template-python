from __future__ import annotations

import uuid

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.release import Release
from com.xebialabs.xlrelease.domain.risk import (
    Risk,
    RiskAssessor,
    RiskGlobalThresholds,
    RiskProfile,
)


class RiskApi:
    """Operations on risk."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the RiskApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getRisk(self, riskIdOrRelease: str | Release) -> Risk:
        """
        Returns the release risk score.

        :param riskIdOrRelease: the full identifier of the release risk score
            (``{releaseId}/Risk``) or a Release object.
        :return: the risk.
        """
        if isinstance(riskIdOrRelease, Release):
            release_id = riskIdOrRelease.id
            if not release_id:
                raise ValueError("release.id must be set to get its risk")
            risk_id = release_id if release_id.endswith("/Risk") else f"{release_id}/Risk"
        else:
            risk_id = riskIdOrRelease
        response = self.api.get(f"/api/v1/risks/{risk_id}")
        return Risk.from_response(response)

    def getRiskGlobalThresholds(self) -> RiskGlobalThresholds:
        """
        Returns the global risk thresholds configuration.

        :return: the global risk thresholds.
        """
        response = self.api.get("/api/v1/risks/config")
        return RiskGlobalThresholds.from_response(response)

    def updateRiskGlobalThresholds(self, thresholds: RiskGlobalThresholds) -> RiskGlobalThresholds:
        """
        Updates the global risk thresholds configuration.

        :param thresholds: the updated global risk thresholds.
        :return: the updated global risk thresholds.
        """
        response = self.api.put(
            "/api/v1/risks/config",
            json=thresholds.model_dump(exclude_none=True)
        )
        return RiskGlobalThresholds.from_response(response)

    def getRiskProfiles(self) -> list[RiskProfile]:
        """
        Returns the list of all risk profile configurations.

        :return: the list of risk profiles.
        """
        response = self.api.get("/api/v1/risks/profiles")
        return RiskProfile.from_response_to_list(response)

    def getRiskProfile(self, riskProfileId: str) -> RiskProfile:
        """
        Returns the risk profile for the given identifier.

        :param riskProfileId: the full identifier of the risk profile.
        :return: the risk profile.
        """
        response = self.api.get(f"/api/v1/risks/profiles/{riskProfileId}")
        return RiskProfile.from_response(response)

    def getRiskProfileByTitle(self, title: str) -> RiskProfile | None:
        """
        Returns the risk profile with the given title.

        :param title: the title of the risk profile.
        :return: the matching risk profile, or None if not found.
        """
        for profile in self.getRiskProfiles():
            if profile.title == title:
                return profile
        return None

    def updateRiskProfile(
            self,
            riskProfileIdOrProfile: str | RiskProfile,
            riskProfile: RiskProfile | None = None
    ) -> RiskProfile:
        """
        Updates a risk profile.

        Can be called either as ``updateRiskProfile(riskProfileId, riskProfile)`` or
        as ``updateRiskProfile(riskProfile)``.

        :param riskProfileIdOrProfile: the risk profile id, or the risk profile to update.
        :param riskProfile: the updated risk profile (when an id is supplied first).
        :return: the updated risk profile.
        """
        profile: RiskProfile | None
        if isinstance(riskProfileIdOrProfile, RiskProfile):
            profile = riskProfileIdOrProfile
            profile_id = profile.id
        else:
            profile_id = riskProfileIdOrProfile
            profile = riskProfile
        if not profile_id or profile is None:
            raise ValueError("A risk profile id and body are required to update a risk profile")
        response = self.api.put(
            f"/api/v1/risks/profiles/{profile_id}",
            json=profile.model_dump(exclude_none=True)
        )
        return RiskProfile.from_response(response)

    def createRiskProfile(self, riskProfile: RiskProfile) -> RiskProfile:
        """
        Creates a risk profile.

        :param riskProfile: the new risk profile.
        :return: the created risk profile.
        """
        payload = riskProfile.model_dump(exclude_none=True)
        # The server requires the configuration item id to be supplied on create;
        # generate one when the caller has not set it (mirrors the other
        # create* methods in this client).
        if not payload.get("id"):
            payload["id"] = f"Configuration/riskProfiles/RiskProfile{uuid.uuid4().hex}"
        if not payload.get("type"):
            payload["type"] = "xlrelease.RiskProfile"
        response = self.api.post(
            "/api/v1/risks/profiles",
            json=payload
        )
        return RiskProfile.from_response(response)

    def deleteRiskProfile(self, riskProfileIdOrProfile: str | RiskProfile) -> None:
        """
        Deletes a risk profile.

        :param riskProfileIdOrProfile: the risk profile id or the risk profile to delete.
        """
        if isinstance(riskProfileIdOrProfile, RiskProfile):
            profile_id = riskProfileIdOrProfile.id
        else:
            profile_id = riskProfileIdOrProfile
        if not profile_id:
            raise ValueError("A risk profile id is required to delete a risk profile")
        response = self.api.delete(f"/api/v1/risks/profiles/{profile_id}")
        response.raise_for_status()

    def copyRiskProfile(self, riskProfileIdOrProfile: str | RiskProfile) -> RiskProfile:
        """
        Makes a copy of a risk profile.

        :param riskProfileIdOrProfile: the risk profile id or the risk profile to copy.
        :return: the copied risk profile.
        """
        if isinstance(riskProfileIdOrProfile, RiskProfile):
            profile_id = riskProfileIdOrProfile.id
        else:
            profile_id = riskProfileIdOrProfile
        if not profile_id:
            raise ValueError("A risk profile id is required to copy a risk profile")
        response = self.api.post(f"/api/v1/risks/profiles/{profile_id}/copy")
        return RiskProfile.from_response(response)

    def getAllRiskAssessors(self) -> list[RiskAssessor]:
        """
        Returns the list of all risk assessors.

        :return: the list of risk assessors.
        """
        response = self.api.get("/api/v1/risks/assessors")
        return RiskAssessor.from_response_to_list(response)
