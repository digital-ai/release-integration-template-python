from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.role import RoleView


class RolesApi:
    """Operations on roles."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the RolesApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def searchRoles(
            self,
            page: int | None = None,
            resultsPerPage: int | None = None,
            roleName: str | None = None,
            principalName: str | None = None
    ) -> list[RoleView]:
        """
        Searches roles.

        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :param roleName: an optional filter on the role name.
        :param principalName: an optional filter on the principal name.
        :return: a list of roles.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if roleName is not None:
            params["roleName"] = roleName
        if principalName is not None:
            params["principalName"] = principalName
        response = self.api.get("/api/v1/roles", params=params)
        return RoleView.from_response_to_list(response)

    def getRoles(
            self,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[RoleView]:
        """
        Returns the paginated list of roles ordered by role name.

        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :return: a list of roles.
        """
        return self.searchRoles(page=page, resultsPerPage=resultsPerPage)

    def getRole(self, roleName: str) -> RoleView:
        """
        Gets a role by name.

        :param roleName: the role name.
        :return: the role.
        """
        response = self.api.get(f"/api/v1/roles/{roleName}")
        return RoleView.from_response(response)

    def create(self, roleName: str, roleView: RoleView) -> None:
        """
        Creates a role.

        :param roleName: the role name.
        :param roleView: the role to create.
        """
        response = self.api.post(
            f"/api/v1/roles/{roleName}",
            json=roleView.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def createBulk(self, roleViews: list[RoleView]) -> None:
        """
        Creates multiple roles.

        :param roleViews: the list of roles to create.
        """
        response = self.api.post(
            "/api/v1/roles",
            json=[r.model_dump(exclude_none=True) for r in roleViews]
        )
        response.raise_for_status()

    def update(self, roleName: str, roleView: RoleView) -> None:
        """
        Updates a role.

        :param roleName: the role name.
        :param roleView: the updated role.
        """
        response = self.api.put(
            f"/api/v1/roles/{roleName}",
            json=roleView.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def updateBulk(self, roleViews: list[RoleView]) -> None:
        """
        Updates multiple roles.

        :param roleViews: the list of roles to update.
        """
        response = self.api.put(
            "/api/v1/roles",
            json=[r.model_dump(exclude_none=True) for r in roleViews]
        )
        response.raise_for_status()

    def delete(self, roleName: str) -> None:
        """
        Deletes a role.

        :param roleName: the role name.
        """
        response = self.api.delete(f"/api/v1/roles/{roleName}")
        response.raise_for_status()

    def rename(self, roleName: str, newName: str) -> None:
        """
        Renames a role.

        :param roleName: the current role name.
        :param newName: the new name for the role.
        """
        response = self.api.post(f"/api/v1/roles/{roleName}/rename", params={"newName": newName})
        response.raise_for_status()
