from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.forms import ReleasesFilters
from com.xebialabs.xlrelease.domain.release import Release


class SearchApi:
    """Search operations across releases and templates."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the SearchApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def searchReleases(
            self,
            releasesFilters: ReleasesFilters,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Searches releases by filters.

        :param releasesFilters: the search criteria.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default and maximum value is 100.
        :return: the list of matching releases.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.post(
            "/api/v1/releases/search",
            json=releasesFilters.model_dump(exclude_none=True),
            params=params
        )
        return Release.from_response_to_list(response)

    def searchReleasesByTitle(self, releaseTitle: str) -> list[Release]:
        """
        Search releases by given title (exact match).

        :param releaseTitle: the title of the release.
        :return: a list of releases.
        """
        params = {"releaseTitle": releaseTitle}
        response = self.api.get("/api/v1/releases/byTitle", params=params)
        return Release.from_response_to_list(response)

    def searchTemplates(
            self,
            title: str | None = None,
            tags: list[str] | None = None,
            kind: str | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Searches templates by filters.

        :param title: an optional search filter containing the title of the template.
        :param tags: an optional search filter containing list of template tags.
        :param kind: the kind of template (e.g. RELEASE, WORKFLOW). Default is RELEASE.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :return: the list of matching templates.
        """
        params = {}
        if title is not None:
            params["title"] = title
        if tags is not None:
            params["tag"] = tags
        if kind is not None:
            params["kind"] = kind
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get("/api/v1/templates", params=params)
        return Release.from_response_to_list(response)

    def countReleases(self, releasesFilters: ReleasesFilters) -> dict:
        """
        Count releases matching filter criteria.

        :param releasesFilters: the search criteria.
        :return: a map containing the number of releases (total) and the number by status.
        """
        response = self.api.post(
            "/api/v1/releases/count",
            json=releasesFilters.model_dump(exclude_none=True)
        )
        response.raise_for_status()
        return response.json()

    def fullSearchReleases(
            self,
            releasesFilters: ReleasesFilters,
            page: int | None = None,
            archivePage: int | None = None,
            resultsPerPage: int | None = None,
            archiveResultsPerPage: int | None = None
    ) -> dict:
        """
        Searches releases across active and archive databases.

        :param releasesFilters: the search criteria.
        :param page: next page to query, active database.
        :param archivePage: next page to query, archive database.
        :param resultsPerPage: releases per page, active database.
        :param archiveResultsPerPage: releases per page, archive database.
        :return: the full search result.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if archivePage is not None:
            params["archivePage"] = archivePage
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        if archiveResultsPerPage is not None:
            params["archiveResultsPerPage"] = archiveResultsPerPage
        response = self.api.post(
            "/api/v1/releases/fullSearch",
            json=releasesFilters.model_dump(exclude_none=True),
            params=params
        )
        response.raise_for_status()
        return response.json()
