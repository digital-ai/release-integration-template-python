from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.attachment import Attachment
from com.xebialabs.xlrelease.domain.forms import Comment, Condition
from com.xebialabs.xlrelease.domain.gate import Dependency, GateCondition
from com.xebialabs.xlrelease.domain.task import Task
from com.xebialabs.xlrelease.domain.variable import Variable


class TaskApi:
    """Operations on tasks."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the TaskApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getTask(self, taskId: str) -> Task:
        """
        Returns a task by ID.

        :param taskId: the task identifier.
        :return: the task which has the given identifier.
        """
        response = self.api.get(f"/api/v1/tasks/{taskId}")
        return Task.from_response(response)

    def updateTask(self, taskId: str | Task, task: Task | None = None) -> Task:
        """
        Updates a task.

        Supports two calling conventions:
        - updateTask(task): uses task.id as the identifier.
        - updateTask(taskId, task): explicit task ID.

        :param taskId: the task identifier, or a Task object (uses its id).
        :param task: new contents of the task. If taskId is a Task, this is ignored.
        :return: the updated task.
        """
        if isinstance(taskId, Task):
            task = taskId
            taskId = task.id
        response = self.api.put(
            f"/api/v1/tasks/{taskId}",
            json=task.model_dump(exclude_none=True)
        )
        return Task.from_response(response)

    def addTask(self, containerId: str, task: Task, position: int | None = None) -> Task:
        """
        Adds a task to a phase or a container task.

        :param containerId: the identifier of the task container.
        :param task: the task to add.
        :param position: the position at which the task will be added.
        :return: the added task.
        """
        params = {}
        if position is not None:
            params["position"] = position
        body = task.model_dump(exclude_none=True)
        body.setdefault("type", "xlrelease.Task")
        if "id" not in body:
            import uuid
            body["id"] = f"task_{uuid.uuid4().hex[:8]}"
        response = self.api.post(
            f"/api/v1/tasks/{containerId}/tasks",
            json=body,
            params=params
        )
        return Task.from_response(response)

    def copyTask(
            self,
            taskId: str,
            targetContainerId: str,
            targetPosition: int
    ) -> Task:
        """
        Copy a task.

        :param taskId: the task identifier.
        :param targetContainerId: identifier of the target task container.
        :param targetPosition: the position where to copy the task to.
        :return: the copy of the task.
        """
        params = {
            "targetContainerId": targetContainerId,
            "targetPosition": targetPosition
        }
        response = self.api.post(f"/api/v1/tasks/{taskId}/copy", params=params)
        return Task.from_response(response)

    def changeTaskType(self, taskId: str, targetType: str) -> Task:
        """
        Changes a task type to the target type.

        :param taskId: the identifier of the task.
        :param targetType: the new task type (e.g. "xlrelease.GateTask", "jenkins.Build").
        :return: task with new type.
        """
        params = {"targetType": targetType}
        response = self.api.post(f"/api/v1/tasks/{taskId}/changeType", params=params)
        return Task.from_response(response)

    def completeTask(self, taskId: str, comment: str | Comment | None = None) -> Task:
        """
        Completes a task.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'complete' action.
            Can be a string or a Comment object.
        :return: the updated task.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        elif comment:
            body = {"comment": comment}
        else:
            body = {}
        response = self.api.post(f"/api/v1/tasks/{taskId}/complete", json=body)
        return Task.from_response(response)

    def skipTask(self, taskId: str, comment: str | Comment | None = None) -> Task:
        """
        Skips a task.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'skip' action.
            Can be a string or a Comment object.
        :return: the skipped task with the added comment.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        elif comment:
            body = {"comment": comment}
        else:
            body = {}
        response = self.api.post(f"/api/v1/tasks/{taskId}/skip", json=body)
        return Task.from_response(response)

    def failTask(self, taskId: str, comment: str | Comment | None = None) -> Task:
        """
        Fails a task.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'fail' action.
            Can be a string or a Comment object.
        :return: the failed task with the added comment.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        elif comment:
            body = {"comment": comment}
        else:
            body = {}
        response = self.api.post(f"/api/v1/tasks/{taskId}/fail", json=body)
        return Task.from_response(response)

    def abortTask(self, taskId: str, comment: str | Comment | None = None) -> Task:
        """
        Aborts a task.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'abort' action.
            Can be a string or a Comment object.
        :return: the aborted task with the added comment.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        elif comment:
            body = {"comment": comment}
        else:
            body = {}
        response = self.api.post(f"/api/v1/tasks/{taskId}/abort", json=body)
        return Task.from_response(response)

    def retryTask(self, taskId: str, comment: str | Comment | None = None) -> Task:
        """
        Retry failed task.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'retry' action.
            Can be a string or a Comment object.
        :return: the retried task with the added comment.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        elif comment:
            body = {"comment": comment}
        else:
            body = {}
        response = self.api.post(f"/api/v1/tasks/{taskId}/retry", json=body)
        return Task.from_response(response)

    def start(self, taskId: str, comment: str | Comment | None = None, variables: list[Variable] | None = None) -> Task:
        """
        Start pending task.

        When variables are provided, uses the /start endpoint to start a task
        with variable values (e.g. a UserInputTask). Otherwise, uses the
        /startNow endpoint to immediately start a scheduled-pending task.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'startNow' action.
            Can be a string or a Comment object.
        :param variables: list of Variable objects to submit when starting the task.
        :return: the started task.
        """
        if variables is not None:
            body = {"variables": [v.model_dump(exclude_none=True) for v in variables]}
            response = self.api.post(f"/api/v1/tasks/{taskId}/start", json=body)
        else:
            if isinstance(comment, Comment):
                body = comment.model_dump(exclude_none=True)
            elif comment:
                body = {"comment": comment}
            else:
                body = {}
            response = self.api.post(f"/api/v1/tasks/{taskId}/startNow", json=body)
        return Task.from_response(response)

    def reopenTask(self, taskId: str, comment: str | Comment | None = None) -> Task:
        """
        Reopen a task that has been completed in advance.

        :param taskId: the task identifier.
        :param comment: a comment describing the 'reopen' action.
            Can be a string or a Comment object.
        :return: the reopened task with the added comment.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        elif comment:
            body = {"comment": comment}
        else:
            body = {}
        response = self.api.post(f"/api/v1/tasks/{taskId}/reopen", json=body)
        return Task.from_response(response)

    def getVariables(self, taskId: str) -> list[Variable]:
        """
        Return the variables used by the task input fields.

        :param taskId: the task identifier.
        :return: input variables used by the task.
        """
        response = self.api.get(f"/api/v1/tasks/{taskId}/variables")
        return Variable.from_response_to_list(response)

    def updateInputVariables(self, taskId: str, variables: list[Variable]) -> list[Variable]:
        """
        Updates the variables values of a UserInputTask.

        :param taskId: the task identifier.
        :param variables: the variables with values to be updated.
        :return: the updated variables.
        """
        response = self.api.put(
            f"/api/v1/tasks/{taskId}/variables",
            json=[v.model_dump(exclude_none=True) for v in variables]
        )
        return Variable.from_response_to_list(response)

    def commentTask(self, taskId: str, comment: str | Comment) -> Task:
        """
        Adds a comment to a task.

        :param taskId: the task identifier.
        :param comment: the comment text or Comment object to be added to the task.
        :return: the updated task.
        """
        if isinstance(comment, Comment):
            body = comment.model_dump(exclude_none=True)
        else:
            body = {"comment": comment}
        response = self.api.post(f"/api/v1/tasks/{taskId}/comment", json=body)
        return Task.from_response(response)

    def assignTask(self, taskId: str, username: str) -> Task:
        """
        Assigns a task to a user.

        :param taskId: the task identifier.
        :param username: the username of the user the task will be assigned to.
        :return: the updated task.
        """
        response = self.api.post(f"/api/v1/tasks/{taskId}/assign/{username}")
        return Task.from_response(response)

    def searchTasksByTitle(
            self,
            taskTitle: str,
            releaseId: str,
            phaseTitle: str | None = None
    ) -> list[Task]:
        """
        Search tasks by title within a release.

        :param taskTitle: the task title.
        :param releaseId: the release identifier.
        :param phaseTitle: the phase title (optional).
        :return: a list of tasks that match the title within the release.
        """
        params: dict[str, str] = {"taskTitle": taskTitle, "releaseId": releaseId}
        if phaseTitle is not None:
            params["phaseTitle"] = phaseTitle
        response = self.api.get("/api/v1/tasks/byTitle", params=params)
        return Task.from_response_to_list(response)

    def newTask(self, taskType: str | None = None) -> Task:
        """
        Factory method to create a new instance of a Task object.

        :param taskType: the type of the task (e.g. "xlrelease.GateTask"). If not provided,
            creates a Manual Task.
        :return: the task object.
        """
        task = Task(type=taskType) if taskType else Task()
        return task

    def newComment(self, commentText: str) -> Comment:
        """
        Factory method to create a new instance of a Comment object.

        :param commentText: the comment text.
        :return: the comment object.
        """
        return Comment(comment=commentText)

    def delete(self, taskId: str) -> None:
        """
        Deletes a task.

        :param taskId: the task identifier.
        """
        response = self.api.delete(f"/api/v1/tasks/{taskId}")
        response.raise_for_status()

    def addAttachment(self, taskId: str, fileName: str, fileBytes: bytes) -> Attachment:
        """
        Adds one attachment file to a task.

        :param taskId: the task identifier.
        :param fileName: the name of the attachment file.
        :param fileBytes: the file content as bytes.
        :return: the domain object of the uploaded attachment.
        """
        files = {"file": (fileName, fileBytes)}
        response = self.api.post(
            f"/api/v1/tasks/{taskId}/attachments",
            files=files
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return Attachment.model_validate(data[0])
        return Attachment.model_validate(data)

    def addAttachments(self, taskId: str, fileList: list[tuple[str, bytes]]) -> list[Attachment]:
        """
        Adds multiple attachment files to a task.

        :param taskId: the task identifier.
        :param fileList: list of (fileName, fileBytes) tuples.
        :return: list of uploaded Attachment domain objects.
        """
        files = [("file", (name, content)) for name, content in fileList]
        response = self.api.post(
            f"/api/v1/tasks/{taskId}/attachments",
            files=files
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return [Attachment.model_validate(item) for item in data]
        return [Attachment.model_validate(data)]

    def getAttachment(self, attachmentId: str) -> bytes:
        """
        Downloads an attachment file by its ID.

        :param attachmentId: the full identifier of the attachment;
            for example, Applications/Release1/Attachment1.
        :return: the attachment file content as bytes.
        """
        response = self.api.get(
            f"/api/v1/releases/attachments/{attachmentId}",
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response.content

    def deleteAttachment(self, taskId: str, attachmentId: str) -> None:
        """
        Deletes an attachment from a task.

        :param taskId: the task identifier.
        :param attachmentId: the attachment identifier.
        """
        response = self.api.delete(f"/api/v1/tasks/{taskId}/attachments/{attachmentId}")
        response.raise_for_status()

    def addDependency(self, taskId: str, targetId: str) -> Dependency:
        """
        Adds a dependency to a gate task.

        :param taskId: the identifier of the gate task to add the dependency to.
        :param targetId: the identifier of the release, phase or task that the gate will depend on.
        :return: the added Dependency.
        """
        response = self.api.post(f"/api/v1/tasks/{taskId}/dependencies/{targetId}")
        return Dependency.from_response(response)

    def deleteDependency(self, dependencyId: str) -> None:
        """
        Deletes a dependency from a gate task.

        :param dependencyId: the identifier of the gate task dependency.
        """
        response = self.api.delete(f"/api/v1/tasks/{dependencyId}")
        response.raise_for_status()

    def addCondition(self, taskId: str, condition: Condition) -> GateCondition:
        """
        Adds a condition to a gate task.

        :param taskId: the identifier of the gate task to add the condition to.
        :param condition: the condition to add.
        :return: the added gate condition.
        """
        response = self.api.post(
            f"/api/v1/tasks/{taskId}/conditions",
            json=condition.model_dump(exclude_none=True)
        )
        return GateCondition.from_response(response)

    def updateCondition(self, conditionId: str, condition: Condition) -> GateCondition:
        """
        Updates a condition on a gate task.

        :param conditionId: the identifier of the gate task condition.
        :param condition: the new values of the condition.
        :return: the updated gate condition.
        """
        response = self.api.post(
            f"/api/v1/tasks/{conditionId}",
            json=condition.model_dump(exclude_none=True)
        )
        return GateCondition.from_response(response)

    def deleteCondition(self, conditionId: str) -> None:
        """
        Deletes a condition from a gate task.

        :param conditionId: the identifier of the gate task condition.
        """
        response = self.api.delete(f"/api/v1/tasks/{conditionId}")
        response.raise_for_status()

    def lockTask(self, taskId: str) -> None:
        """
        Locks a task.

        :param taskId: the task identifier.
        """
        response = self.api.put(f"/api/v1/tasks/{taskId}/lock")
        response.raise_for_status()

    def unlockTask(self, taskId: str) -> None:
        """
        Unlocks a task.

        :param taskId: the task identifier.
        """
        response = self.api.delete(f"/api/v1/tasks/{taskId}/lock")
        response.raise_for_status()
