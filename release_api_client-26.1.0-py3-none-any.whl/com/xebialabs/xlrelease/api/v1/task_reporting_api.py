from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.reporting import (
    BuildRecord,
    CodeComplianceRecord,
    DeploymentRecord,
    ItsmRecord,
    PlanRecord,
    TaskReportingRecord,
)


class TaskReportingApi:
    """Operations on task reporting records."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the TaskReportingApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def addRecord(self, record: TaskReportingRecord) -> TaskReportingRecord:
        """
        Adds a new reporting record.

        :param record: the reporting record to add.
        :return: the added reporting record.
        """
        response = self.api.post(
            "/api/v1/tasks/reporting",
            json=record.model_dump(exclude_none=True)
        )
        return TaskReportingRecord.from_response(response)

    def newItsmRecord(self) -> ItsmRecord:
        """
        Factory method to create a new instance of an ITSM record.

        :return: a new ITSM record.
        """
        return ItsmRecord()

    def newPlanRecord(self) -> PlanRecord:
        """
        Factory method to create a new instance of a plan record.

        :return: a new plan record.
        """
        return PlanRecord()

    def newBuildRecord(self) -> BuildRecord:
        """
        Factory method to create a new instance of a build record.

        :return: a new build record.
        """
        return BuildRecord()

    def newDeploymentRecord(self) -> DeploymentRecord:
        """
        Factory method to create a new instance of a deployment record.

        :return: a new deployment record.
        """
        return DeploymentRecord()

    def newCodeComplianceRecord(self) -> CodeComplianceRecord:
        """
        Factory method to create a new instance of a code compliance record.

        :return: a new code compliance record.
        """
        return CodeComplianceRecord()
