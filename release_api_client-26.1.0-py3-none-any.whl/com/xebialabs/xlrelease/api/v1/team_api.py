from __future__ import annotations

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.team import TeamView


class TeamApi:
    """Operations on teams across releases, templates, and folders."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the TeamApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getReleaseTeams(self, releaseId: str) -> list[TeamView]:
        """
        Returns effective teams of the release.

        :param releaseId: the identifier of the release.
        :return: a list of effective teams.
        """
        response = self.api.get(f"/api/v1/releases/{releaseId}/teams")
        return TeamView.from_response_to_list(response)

    def setReleaseTeams(self, releaseId: str, teams: list[TeamView]) -> list[TeamView]:
        """
        Sets teams of the release.

        :param releaseId: the identifier of the release.
        :param teams: the teams to set.
        :return: a list of updated teams.
        """
        response = self.api.post(
            f"/api/v1/releases/{releaseId}/teams",
            json=[t.model_dump(exclude_none=True) for t in teams]
        )
        return TeamView.from_response_to_list(response)

    def getTemplateTeams(self, templateId: str) -> list[TeamView]:
        """
        Returns effective teams of the template.

        :param templateId: the identifier of the template.
        :return: a list of effective teams.
        """
        response = self.api.get(f"/api/v1/templates/{templateId}/teams")
        return TeamView.from_response_to_list(response)

    def setTemplateTeams(self, templateId: str, teams: list[TeamView]) -> list[TeamView]:
        """
        Sets teams of the template.

        :param templateId: the identifier of the template.
        :param teams: the teams to set.
        :return: a list of updated teams.
        """
        response = self.api.post(
            f"/api/v1/templates/{templateId}/teams",
            json=[t.model_dump(exclude_none=True) for t in teams]
        )
        return TeamView.from_response_to_list(response)

    def getFolderTeams(self, folderId: str) -> list[TeamView]:
        """
        Returns folder effective teams.

        :param folderId: the id of the folder.
        :return: list of effective teams.
        """
        response = self.api.get(f"/api/v1/folders/{folderId}/teams")
        return TeamView.from_response_to_list(response)

    def setFolderTeams(self, folderId: str, teams: list[TeamView]) -> list[TeamView]:
        """
        Set teams of the folder.

        :param folderId: the identifier of the folder.
        :param teams: the teams to set.
        :return: a list of updated teams.
        """
        response = self.api.post(
            f"/api/v1/folders/{folderId}/teams",
            json=[t.model_dump(exclude_none=True) for t in teams]
        )
        return TeamView.from_response_to_list(response)

    def createFolderTeam(
            self,
            folderId: str,
            name: str,
            principals: list[str] | None = None,
            roles: list[str] | None = None,
            permissions: list[str] | None = None
    ) -> str:
        """
        Creates a team in a folder.

        :param folderId: the folder identifier.
        :param name: the team name.
        :param principals: the list of principals.
        :param roles: the list of roles.
        :param permissions: the list of permissions.
        :return: the team ID.
        """
        body = {"name": name}
        if principals is not None:
            body["principals"] = principals
        if roles is not None:
            body["roles"] = roles
        if permissions is not None:
            body["permissions"] = permissions
        response = self.api.post(f"/api/v1/folders/{folderId}/create-team", json=body)
        response.raise_for_status()
        return response.text

    def deleteFolderTeamByName(self, folderId: str, teamName: str) -> None:
        """
        Deletes a team by name from a folder.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        """
        response = self.api.delete(f"/api/v1/folders/{folderId}/teams/{teamName}")
        response.raise_for_status()

    def deleteFolderTeamById(self, folderId: str, teamId: str) -> None:
        """
        Deletes a team by ID from a folder.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        """
        response = self.api.delete(f"/api/v1/folders/{folderId}/{teamId}")
        response.raise_for_status()

    def addPrincipalsToTeamById(self, folderId: str, teamId: str, principalNames: list[str]) -> None:
        """
        Adds principals to a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/add-principals",
            json=principalNames
        )
        response.raise_for_status()

    def addPrincipalsToTeamByName(self, folderId: str, teamName: str, principalNames: list[str]) -> None:
        """
        Adds principals to a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/add-principals",
            json=principalNames
        )
        response.raise_for_status()

    def removePrincipalsFromTeamById(self, folderId: str, teamId: str, principalNames: list[str]) -> None:
        """
        Removes principals from a team by team ID.

        :param folderId: the folder identifier.
        :param teamId: the team identifier.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/{teamId}/remove-principals",
            json=principalNames
        )
        response.raise_for_status()

    def removePrincipalsFromTeamByName(self, folderId: str, teamName: str, principalNames: list[str]) -> None:
        """
        Removes principals from a team by team name.

        :param folderId: the folder identifier.
        :param teamName: the team name.
        :param principalNames: the list of principal names.
        """
        response = self.api.put(
            f"/api/v1/folders/{folderId}/teams/{teamName}/remove-principals",
            json=principalNames
        )
        response.raise_for_status()
