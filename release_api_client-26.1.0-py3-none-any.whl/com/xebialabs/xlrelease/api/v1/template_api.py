from __future__ import annotations

import uuid

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.forms import (
    CreateRelease,
    ImportResult,
    StartRelease,
    VariableOrValue,
)
from com.xebialabs.xlrelease.domain.release import Release
from com.xebialabs.xlrelease.domain.team import TeamView
from com.xebialabs.xlrelease.domain.variable import Variable


class TemplateApi:
    """Operations on templates."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the TemplateApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getTemplates(
            self,
            title: str | None = None,
            tags: list[str] | None = None,
            kind: str | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Release]:
        """
        Returns the list of release or workflow templates visible to the current user.

        :param title: an optional search filter containing the title of the template.
        :param tags: an optional search filter containing list of template tags.
        :param kind: the kind of template (e.g. RELEASE, WORKFLOW). Default value is RELEASE.
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :return: a list of release templates.
        """
        params = {}
        if title is not None:
            params["title"] = title
        if tags is not None:
            params["tag"] = tags
        if kind is not None:
            params["kind"] = kind
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get("/api/v1/templates", params=params)
        return Release.from_response_to_list(response)

    def getTemplate(self, templateId: str) -> Release:
        """
        Returns the template for the given identifier.

        :param templateId: the template identifier.
        :return: the release template.
        """
        response = self.api.get(f"/api/v1/templates/{templateId}")
        return Release.from_response(response)

    def updateTemplate(self, templateId: str, template: Release) -> Release:
        """
        Updates the properties of a template.

        :param templateId: the template identifier.
        :param template: new contents of the template.
        :return: the updated release template.
        """
        response = self.api.put(
            f"/api/v1/templates/{templateId}",
            json=template.model_dump(exclude_none=True)
        )
        return Release.from_response(response)

    def createTemplate(self, template: Release, folderId: str | None = None) -> Release:
        """
        Creates a template inside a folder.

        :param template: the contents of the release template.
        :param folderId: an optional parameter to create a template inside a folder.
        :return: the created template.
        """
        params = {}
        if folderId is not None:
            params["folderId"] = folderId
        payload = template.model_dump(exclude_none=True)
        # The server requires the configuration item id to be supplied on create;
        # generate one when the caller has not set it.
        if not payload.get("id"):
            payload["id"] = f"Applications/Release{uuid.uuid4().hex}"
        if not payload.get("type"):
            payload["type"] = "xlrelease.Release"
        if not payload.get("status"):
            payload["status"] = "TEMPLATE"
        response = self.api.post(
            "/api/v1/templates",
            json=payload,
            params=params
        )
        return Release.from_response(response)

    def importTemplate(self, json_str: str, folderId: str | None = None, version: str | None = None) -> list[ImportResult]:
        """
        Imports a template, serialized in JSON format.

        :param json_str: JSON representation of the template.
        :param folderId: the target folder.
        :param version: the version of the template (optional).
        :return: the import results.
        """
        params = {}
        if folderId is not None:
            params["folderId"] = folderId
        if version is not None:
            params["version"] = version
        response = self.api.post(
            "/api/v1/templates/import",
            data=json_str,
            params=params,
            headers={"Content-Type": "application/json"}
        )
        return ImportResult.from_response_to_list(response)

    def importTemplateAsXlr(
            self,
            file: bytes | str,
            folderId: str | None = None,
            filename: str = "template.xlr"
    ) -> list[ImportResult]:
        """
        Imports a template serialized in XLR format, or a Releasefile inside a .zip file.

        :param file: the template file content as bytes, or a path to the file.
        :param folderId: the target folder.
        :param filename: the name of the uploaded file (used when ``file`` is bytes).
        :return: the import results.
        """
        if isinstance(file, str):
            with open(file, "rb") as handle:
                content = handle.read()
            import os
            filename = os.path.basename(file)
        else:
            content = file
        params = {}
        if folderId is not None:
            params["folderId"] = folderId
        response = self.api.post(
            "/api/v1/templates/import",
            params=params,
            files={"file": (filename, content, "application/octet-stream")}
        )
        return ImportResult.from_response_to_list(response)

    def deleteTemplate(self, templateId: str) -> None:
        """
        Deletes a template.

        :param templateId: the template identifier.
        """
        response = self.api.delete(f"/api/v1/templates/{templateId}")
        response.raise_for_status()

    def create(self, templateId: str, createRelease: CreateRelease) -> Release:
        """
        Creates a release from a template.

        :param templateId: the template identifier of the template the release is based on.
        :param createRelease: the parameters for the new release.
        :return: the newly created release.
        """
        response = self.api.post(
            f"/api/v1/templates/{templateId}/create",
            json=createRelease.model_dump(exclude_none=True)
        )
        return Release.from_response(response)

    def start(self, templateId: str, startRelease: StartRelease) -> Release:
        """
        Starts a release from a template.

        :param templateId: the template identifier of the template the release is based on.
        :param startRelease: the parameters for the new release.
        :return: the newly created and started release.
        """
        response = self.api.post(
            f"/api/v1/templates/{templateId}/start",
            json=startRelease.model_dump(exclude_none=True)
        )
        return Release.from_response(response)

    def getVariables(self, templateId: str) -> list[Variable]:
        """
        Get variables.

        :param templateId: the identifier of the template.
        :return: a list of variables.
        """
        response = self.api.get(f"/api/v1/templates/{templateId}/variables")
        return Variable.from_response_to_list(response)

    def getVariable(self, variableId: str) -> Variable:
        """
        Returns the variable for the given identifier.

        :param variableId: the identifier of the variable.
        :return: the variable.
        """
        response = self.api.get(f"/api/v1/templates/{variableId}")
        return Variable.from_response(response)

    def getVariablePossibleValues(self, variableId: str) -> list:
        """
        Returns possible values for the variable with the given identifier.

        :param variableId: the variable identifier.
        :return: possible values for the variable.
        """
        response = self.api.get(f"/api/v1/templates/{variableId}/possibleValues")
        response.raise_for_status()
        return response.json()

    def isVariableUsed(self, variableId: str) -> bool:
        """
        Returns true if variable with the given identifier is used in the template.

        :param variableId: the variable ID.
        :return: true if the variable is used.
        """
        response = self.api.get(f"/api/v1/templates/{variableId}/used")
        response.raise_for_status()
        return response.json()

    def replaceVariable(self, variableId: str, variableOrValue: VariableOrValue) -> None:
        """
        Replace variable occurrences with the given replacement.

        :param variableId: the variable ID.
        :param variableOrValue: an object with a variable or value replacing the initial variable.
        """
        response = self.api.post(
            f"/api/v1/templates/{variableId}/replace",
            json=variableOrValue.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def deleteVariable(self, variableId: str) -> None:
        """
        Delete variable from template.

        :param variableId: the variable ID.
        """
        response = self.api.delete(f"/api/v1/templates/{variableId}")
        response.raise_for_status()

    def createVariable(self, templateId: str, variable: Variable) -> Variable:
        """
        Create a new variable.

        :param templateId: the identifier of a template.
        :param variable: the Variable object describing the new variable.
        :return: created Variable object.
        """
        response = self.api.post(
            f"/api/v1/templates/{templateId}/variables",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def updateVariables(self, templateId: str, variables: list[Variable]) -> list[Variable]:
        """
        Update the variable list.

        :param templateId: the identifier of the template.
        :param variables: the variable list to update.
        :return: updated variables.
        """
        response = self.api.put(
            f"/api/v1/templates/{templateId}/variables",
            json=[v.model_dump(exclude_none=True) for v in variables]
        )
        return Variable.from_response_to_list(response)

    def updateVariable(self, variableId: str, variable: Variable) -> Variable:
        """
        Updates the properties of a variable.

        :param variableId: the variable identifier.
        :param variable: new contents of the variable.
        :return: the updated variable.
        """
        response = self.api.put(
            f"/api/v1/templates/{variableId}",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def getPermissions(self) -> list[str]:
        """
        Returns possible permissions.

        :return: list of permissions for templates and releases.
        """
        response = self.api.get("/api/v1/templates/permissions")
        response.raise_for_status()
        return response.json()

    def getTeams(self, templateId: str) -> list[TeamView]:
        """
        Returns effective teams of the template.

        :param templateId: the identifier of the template.
        :return: a list of effective teams.
        """
        response = self.api.get(f"/api/v1/templates/{templateId}/teams")
        return TeamView.from_response_to_list(response)

    def setTeams(self, templateId: str, teams: list[TeamView]) -> list[TeamView]:
        """
        Sets teams of the template.

        :param templateId: the identifier of the template.
        :param teams: the teams to set.
        :return: a list of updated teams.
        """
        response = self.api.post(
            f"/api/v1/templates/{templateId}/teams",
            json=[t.model_dump(exclude_none=True) for t in teams]
        )
        return TeamView.from_response_to_list(response)

    def copyTemplate(self, templateId: str, title: str, description: str | None = None) -> Release:
        """
        Makes a copy of the template on the current folder.

        :param templateId: the full template ID.
        :param title: the new template title.
        :param description: the new template description.
        :return: the new template.
        """
        body = {"title": title}
        if description is not None:
            body["description"] = description
        response = self.api.post(f"/api/v1/templates/{templateId}/copy", json=body)
        return Release.from_response(response)

    def exportTemplateToZip(self, templateId: str) -> bytes:
        """
        Exports a template to a zip file.

        :param templateId: the template identifier.
        :return: the zip file content as bytes.
        """
        response = self.api.get(
            f"/api/v1/templates/zip/{templateId}",
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response.content

    def downloadTemplateLogo(self, logoId: str) -> bytes:
        """
        Downloads a template logo.

        :param logoId: the identifier of the template logo.
        :return: the logo content as bytes.
        """
        response = self.api.get(
            f"/api/v1/templates/logo/{logoId}",
            headers={"Accept": "application/octet-stream"}
        )
        response.raise_for_status()
        return response.content
