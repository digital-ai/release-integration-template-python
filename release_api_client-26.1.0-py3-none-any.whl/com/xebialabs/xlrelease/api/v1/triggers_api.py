from __future__ import annotations

import uuid

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.trigger import Trigger


class TriggersApi:
    """Operations on triggers."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the TriggersApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getTrigger(self, triggerId: str) -> Trigger:
        """
        Gets a trigger by ID.

        :param triggerId: the trigger identifier.
        :return: the trigger.
        """
        response = self.api.get(f"/api/v1/triggers/{triggerId}")
        return Trigger.from_response(response)

    def addTrigger(self, trigger: Trigger) -> Trigger:
        """
        Adds a new trigger.

        :param trigger: the trigger to add.
        :return: the added trigger.
        """
        data = trigger.model_dump(exclude_none=True)
        if "id" not in data:
            data["id"] = f"Trigger_{uuid.uuid4().hex}"
        response = self.api.post(
            "/api/v1/triggers",
            json=data
        )
        return Trigger.from_response(response)

    def updateTrigger(self, triggerId: str, trigger: Trigger) -> Trigger:
        """
        Updates a trigger.

        :param triggerId: the trigger identifier.
        :param trigger: the updated trigger.
        :return: the updated trigger.
        """
        response = self.api.put(
            f"/api/v1/triggers/{triggerId}",
            json=trigger.model_dump(exclude_none=True)
        )
        return Trigger.from_response(response)

    def enableTrigger(self, triggerId: str) -> None:
        """
        Enables a trigger.

        :param triggerId: the trigger identifier.
        """
        response = self.api.put(f"/api/v1/triggers/{triggerId}/enable")
        response.raise_for_status()

    def enableTriggers(self, triggerIds: list[str]) -> dict:
        """
        Enables multiple triggers.

        :param triggerIds: the list of trigger IDs to enable.
        :return: bulk action result.
        """
        response = self.api.post("/api/v1/triggers/enable", json=triggerIds)
        response.raise_for_status()
        return response.json()

    def enableAllTriggers(self) -> dict:
        """
        Enables all triggers.

        :return: bulk action result.
        """
        response = self.api.post("/api/v1/triggers/enable/all")
        response.raise_for_status()
        return response.json()

    def disableTrigger(self, triggerId: str) -> None:
        """
        Disables a trigger.

        :param triggerId: the trigger identifier.
        """
        response = self.api.put(f"/api/v1/triggers/{triggerId}/disable")
        response.raise_for_status()

    def disableTriggers(self, triggerIds: list[str]) -> dict:
        """
        Disables multiple triggers.

        :param triggerIds: the list of trigger IDs to disable.
        :return: bulk action result.
        """
        response = self.api.post("/api/v1/triggers/disable", json=triggerIds)
        response.raise_for_status()
        return response.json()

    def disableAllTriggers(self) -> dict:
        """
        Disables all triggers.

        :return: bulk action result.
        """
        response = self.api.post("/api/v1/triggers/disable/all")
        response.raise_for_status()
        return response.json()

    def removeTrigger(self, triggerId: str) -> None:
        """
        Removes a trigger.

        :param triggerId: the trigger identifier.
        """
        response = self.api.delete(f"/api/v1/triggers/{triggerId}")
        response.raise_for_status()

    def getTypes(self) -> list:
        """
        Gets available trigger types.

        :return: a list of trigger type descriptors.
        """
        response = self.api.get("/api/v1/triggers/types")
        response.raise_for_status()
        return response.json()

    def searchTriggers(
            self,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[Trigger]:
        """
        Searches triggers.

        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :return: a list of triggers.
        """
        params = {}
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get("/api/v1/triggers", params=params)
        response.raise_for_status()
        data = response.json()
        if isinstance(data, dict) and "content" in data:
            return [Trigger.from_dict(item) for item in data["content"]]
        elif isinstance(data, list):
            return [Trigger.from_dict(item) for item in data]
        return []

    def runTrigger(self, triggerId: str) -> None:
        """
        Runs a trigger manually.

        :param triggerId: the trigger identifier.
        """
        response = self.api.post(f"/api/v1/triggers/{triggerId}/run")
        response.raise_for_status()
