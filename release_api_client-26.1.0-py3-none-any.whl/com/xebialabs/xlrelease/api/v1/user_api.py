from __future__ import annotations

from datetime import datetime

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.user import UserAccount


class UserApi:
    """Operations on users."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the UserApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def findUsers(
            self,
            email: str | None = None,
            fullName: str | None = None,
            loginAllowed: bool | None = None,
            external: bool | None = None,
            lastActiveAfter: str | None = None,
            lastActiveBefore: str | None = None,
            page: int | None = None,
            resultsPerPage: int | None = None
    ) -> list[UserAccount]:
        """
        Finds users by filters.

        :param email: filter by email.
        :param fullName: filter by full name.
        :param loginAllowed: filter by login allowed status.
        :param external: filter by external status.
        :param lastActiveAfter: filter by last active after date (ISO format).
        :param lastActiveBefore: filter by last active before date (ISO format).
        :param page: the page of results to return. Default value is 0.
        :param resultsPerPage: the number of results per page. Default value is 100.
        :return: a list of user accounts.
        """
        params = {}
        if email is not None:
            params["email"] = email
        if fullName is not None:
            params["fullName"] = fullName
        if loginAllowed is not None:
            params["loginAllowed"] = loginAllowed
        if external is not None:
            params["external"] = external
        if lastActiveAfter is not None:
            params["lastActiveAfter"] = lastActiveAfter
        if lastActiveBefore is not None:
            params["lastActiveBefore"] = lastActiveBefore
        if page is not None:
            params["page"] = page
        if resultsPerPage is not None:
            params["resultsPerPage"] = resultsPerPage
        response = self.api.get("/api/v1/users", params=params)
        return UserAccount.from_response_to_list(response)

    def getUser(self, username: str) -> UserAccount:
        """
        Gets a user by username.

        :param username: the username.
        :return: the user account.
        """
        response = self.api.get(f"/api/v1/users/{username}")
        return UserAccount.from_response(response)

    def createUser(self, username: str, userAccount: UserAccount) -> None:
        """
        Creates a new user.

        :param username: the username for the new user.
        :param userAccount: the user account details.
        """
        response = self.api.post(
            f"/api/v1/users/{username}",
            json=userAccount.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def updateUser(self, username: str, userAccount: UserAccount) -> None:
        """
        Updates an existing user.

        :param username: the username of the user to update.
        :param userAccount: the updated user account details.
        """
        response = self.api.put(
            f"/api/v1/users/{username}",
            json=userAccount.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def updateUsersRest(self, userAccounts: list[UserAccount]) -> None:
        """
        Updates a collection of users.

        :param userAccounts: the user accounts to update.
        """
        response = self.api.put(
            "/api/v1/users",
            json=[u.model_dump(exclude_none=True) for u in userAccounts]
        )
        response.raise_for_status()

    def updateUsers(self, userAccounts: list[UserAccount]) -> None:
        """
        Updates a collection of users.

        :param userAccounts: the user accounts to update.
        """
        self.updateUsersRest(userAccounts)

    def updatePassword(self, username: str, currentPassword: str, newPassword: str) -> None:
        """
        Updates the password for a user.

        :param username: the username.
        :param currentPassword: the current password.
        :param newPassword: the new password.
        """
        body = {"currentPassword": currentPassword, "newPassword": newPassword}
        response = self.api.post(f"/api/v1/users/{username}/password", json=body)
        response.raise_for_status()

    def deleteUser(self, username: str) -> None:
        """
        Deletes a user.

        :param username: the username of the user to delete.
        """
        response = self.api.delete(f"/api/v1/users/{username}")
        response.raise_for_status()

    def deleteUserRest(self, username: str) -> None:
        """
        Deletes a user.

        :param username: the username of the user to delete.
        """
        self.deleteUser(username)

    def unlockUser(self, username: str) -> None:
        """
        Unlocks a locked user account.

        :param username: the username of the user to unlock.
        """
        response = self.api.post(f"/api/v1/users/{username}/unlock")
        response.raise_for_status()
