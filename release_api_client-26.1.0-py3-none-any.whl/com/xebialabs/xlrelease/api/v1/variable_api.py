from __future__ import annotations

from typing import Any

from digitalai.release.release_api_client import ReleaseAPIClient

from com.xebialabs.xlrelease.domain.forms import VariableOrValue
from com.xebialabs.xlrelease.domain.variable import Variable


class VariableApi:
    """Operations on variables across releases, templates, and folders."""

    def __init__(self, api: ReleaseAPIClient):
        """
        Initializes the VariableApi.

        :param api: an instance of ReleaseAPIClient used to make HTTP requests.
        """
        self.api = api

    def getVariables(self, containerId: str) -> list[Variable]:
        """
        Get variables for a release or template.

        :param containerId: the identifier of the release or template.
        :return: a list of variables.
        """
        response = self.api.get(f"/api/v1/releases/{containerId}/variables")
        return Variable.from_response_to_list(response)

    def getVariableValues(self, containerId: str) -> dict[str, str]:
        """
        Get variable values for a release or template.

        :param containerId: the identifier of the release or template.
        :return: a map of variable values.
        """
        response = self.api.get(f"/api/v1/releases/{containerId}/variableValues")
        response.raise_for_status()
        return response.json()

    def getVariable(self, variableId: str) -> Variable:
        """
        Returns the variable for the given identifier.

        :param variableId: the variable identifier.
        :return: the variable.
        """
        response = self.api.get(f"/api/v1/releases/{variableId}")
        return Variable.from_response(response)

    def getVariablePossibleValues(self, variableId: str) -> list:
        """
        Returns possible values for the variable with the given identifier.

        :param variableId: the variable identifier.
        :return: possible values for the variable.
        """
        response = self.api.get(f"/api/v1/releases/{variableId}/possibleValues")
        response.raise_for_status()
        return response.json()

    def isVariableUsed(self, variableId: str) -> bool:
        """
        Returns true if variable with the given identifier is used.

        :param variableId: the variable ID.
        :return: true if variable is used.
        """
        response = self.api.get(f"/api/v1/releases/{variableId}/used")
        response.raise_for_status()
        return response.json()

    def replaceVariable(self, variableId: str, variableOrValue: VariableOrValue) -> None:
        """
        Replace variable occurrences with the given replacement.

        :param variableId: the variable ID.
        :param variableOrValue: an object with a variable or value replacing the initial variable.
        """
        response = self.api.post(
            f"/api/v1/releases/{variableId}/replace",
            json=variableOrValue.model_dump(exclude_none=True)
        )
        response.raise_for_status()

    def deleteVariable(self, variableId: str) -> None:
        """
        Delete variable.

        :param variableId: the variable ID.
        """
        response = self.api.delete(f"/api/v1/releases/{variableId}")
        response.raise_for_status()

    def createVariable(self, containerId: str, variable: Variable) -> Variable:
        """
        Create new variable.

        :param containerId: the identifier of the release or template.
        :param variable: the variable to create.
        :return: created variable.
        """
        response = self.api.post(
            f"/api/v1/releases/{containerId}/variables",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)

    def updateVariables(self, containerId: str, variables: list[Variable]) -> list[Variable]:
        """
        Update the list of variables.

        :param containerId: the identifier of the release or template.
        :param variables: the variable list to update.
        :return: updated variables.
        """
        response = self.api.put(
            f"/api/v1/releases/{containerId}/variables",
            json=[v.model_dump(exclude_none=True) for v in variables]
        )
        return Variable.from_response_to_list(response)

    def updateVariable(self, variableId: str, variable: Variable) -> Variable:
        """
        Updates the properties of a variable.

        :param variableId: the variable identifier.
        :param variable: new contents of the variable.
        :return: the updated variable.
        """
        response = self.api.put(
            f"/api/v1/releases/{variableId}",
            json=variable.model_dump(exclude_none=True)
        )
        return Variable.from_response(response)
