from __future__ import annotations

from datetime import datetime

from com.xebialabs.xlrelease.domain.base import DomainBase


class ActivityLogEntry(DomainBase):
    """An activity log entry."""

    id: str | None = None
    type: str | None = None
    message: str | None = None
    activityDate: datetime | None = None
    username: str | None = None
    eventType: str | None = None
