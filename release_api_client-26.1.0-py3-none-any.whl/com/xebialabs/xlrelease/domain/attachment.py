from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class Attachment(DomainBase):
    """An attachment in Digital.ai Release."""

    id: str | None = None
    type: str | None = None
    contentType: str | None = None
    fileName: str | None = None
    fileUri: str | None = None
    exportFilename: str | None = None
    portableFilename: str | None = None
