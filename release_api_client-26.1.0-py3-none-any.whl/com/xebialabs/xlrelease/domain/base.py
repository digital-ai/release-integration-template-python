from __future__ import annotations

import json
from typing import Any, Self

from pydantic import BaseModel, ConfigDict


class DomainBase(BaseModel):
    """Base class for all domain objects in the Release SDK."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Serialize the model to a dictionary with JSON-compatible types."""
        kwargs.setdefault("mode", "json")
        return super().model_dump(**kwargs)

    def to_json(self) -> str:
        """Serialize the object to a JSON string, including extra fields."""
        return self.model_dump_json(by_alias=True, exclude_none=True)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create an instance from a dictionary."""
        return cls.model_validate(data)

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        """Create an instance from a JSON string."""
        return cls.model_validate_json(json_str)

    @classmethod
    def from_response(cls, response) -> Self:
        """Create an instance from an HTTP response object."""
        response.raise_for_status()
        return cls.model_validate(response.json())

    @classmethod
    def from_response_to_list(cls, response) -> list[Self]:
        """Create a list of instances from an HTTP response that returns a JSON array."""
        response.raise_for_status()
        return [cls.model_validate(item) for item in response.json()]
