from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class Category(DomainBase):
    """A workflow category."""

    id: str | None = None
    type: str | None = "xlrelease.Category"
    ciUid: int | None = None
    title: str | None = None
    active: bool | None = None


class CategoryView(Category):
    """A category view that also carries usage information."""

    numberOfWorkflows: int | None = None


class CategoryFilters(DomainBase):
    """Search filters for categories."""

    title: str | None = None
    active: bool | None = None
