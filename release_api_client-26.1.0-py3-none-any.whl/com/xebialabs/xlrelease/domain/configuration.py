from __future__ import annotations

from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class Configuration(DomainBase):
    """A shared configuration object in Digital.ai Release."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    properties: dict[str, Any] | None = None
    folderId: str | None = None


class SystemMessageSettings(DomainBase):
    """System message settings."""

    id: str | None = None
    type: str | None = None
    message: str | None = None
    enabled: bool | None = None
