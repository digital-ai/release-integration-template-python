from __future__ import annotations

from datetime import datetime
from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class Delivery(DomainBase):
    """A delivery in Digital.ai Release."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    description: str | None = None
    status: str | None = None
    plannedDuration: int | None = None
    startDate: datetime | None = None
    endDate: datetime | None = None
    folderId: str | None = None
    owner: str | None = None
    releaseIds: list[str] | None = None
    stages: list[Any] | None = None
    trackedItems: list[Any] | None = None
    subscribers: list[str] | None = None
    autoComplete: bool | None = None


class Stage(DomainBase):
    """A stage in a delivery."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    status: str | None = None
    items: list[Any] | None = None
    owner: str | None = None
    team: str | None = None


class Transition(DomainBase):
    """A transition in a delivery stage."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    stage: str | None = None
    conditions: list[Any] | None = None


class TrackedItem(DomainBase):
    """A tracked item in a delivery."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    status: str | None = None
    releaseIds: list[str] | None = None
    descoped: bool | None = None


class DeliveryFilters(DomainBase):
    """Search filters for deliveries."""

    title: str | None = None
    statuses: list[str] | None = None
    folderId: str | None = None
    from_: str | None = None
    to: str | None = None
    orderBy: str | None = None


class DeliveryPatternFilters(DomainBase):
    """Search filters for delivery patterns."""

    title: str | None = None
    folderId: str | None = None


class CreateDelivery(DomainBase):
    """Parameters for creating a delivery from a pattern."""

    title: str | None = None
    startDate: str | None = None
    endDate: str | None = None
    folderId: str | None = None
