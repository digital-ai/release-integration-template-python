from __future__ import annotations

from pydantic import Field

from com.xebialabs.xlrelease.domain.base import DomainBase


class EnvironmentStage(DomainBase):
    """An environment stage (e.g. DEV, TEST, PROD)."""

    id: str | None = None
    type: str | None = "xlrelease.EnvironmentStage"
    title: str | None = None


class EnvironmentLabel(DomainBase):
    """An environment label."""

    id: str | None = None
    type: str | None = "xlrelease.EnvironmentLabel"
    title: str | None = None
    color: str | None = None


class Application(DomainBase):
    """A deployable application."""

    id: str | None = None
    type: str | None = "xlrelease.Application"
    title: str | None = None
    correlationUid: str | None = None
    applicationSource: str | None = None
    environments: list[Environment] | None = None
    tenantId: str | None = None


class Environment(DomainBase):
    """An environment."""

    id: str | None = None
    type: str | None = "xlrelease.Environment"
    title: str | None = None
    correlationUid: str | None = None
    description: str | None = None
    stage: EnvironmentStage | None = None
    stageId: str | None = None
    labels: list[EnvironmentLabel] | None = None
    deploymentTarget: dict | None = None
    tenantId: str | None = None


class EnvironmentReservation(DomainBase):
    """A reservation of an environment for a period of time.

    The server returns ``startDate``/``endDate`` as epoch milliseconds (int)
    on read, but accepts ISO-8601 strings on the reservation form for write,
    so both representations are permitted here.
    """

    id: str | None = None
    type: str | None = "xlrelease.EnvironmentReservation"
    environment: Environment | None = None
    startDate: int | str | None = None
    endDate: int | str | None = None
    applications: list[Application] | None = None
    note: str | None = None


class ApplicationFilters(DomainBase):
    """Search filters for applications."""

    title: str | None = None
    tags: list[str] | None = None


class EnvironmentFilters(DomainBase):
    """Search filters for environments."""

    title: str | None = None
    stageId: str | None = None
    labels: list[str] | None = None


class EnvironmentStageFilters(DomainBase):
    """Search filters for environment stages."""

    title: str | None = None


class EnvironmentLabelFilters(DomainBase):
    """Search filters for environment labels."""

    title: str | None = None


class ReservationFilters(DomainBase):
    """
    Search filters for environment reservations.

    The server requires a date window (``from``/``to``) that spans at most 90 days.
    """

    from_: str | None = Field(default=None, alias="from")
    to: str | None = None
    environmentId: str | None = None
    applicationId: str | None = None
