from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class Folder(DomainBase):
    """A folder in Digital.ai Release."""

    id: str | None = None
    title: str | None = None
    type: str | None = None
    children: list[Folder] | None = None
    path: str | None = None
