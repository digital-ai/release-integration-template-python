from __future__ import annotations

from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class CreateRelease(DomainBase):
    """Parameters for creating a release from a template."""

    releaseTitle: str | None = None
    folderId: str | None = None
    variables: dict[str, Any] | None = None
    releaseVariables: dict[str, Any] | None = None
    releasePasswordVariables: dict[str, Any] | None = None
    scheduledStartDate: str | None = None
    dueDate: str | None = None
    owner: str | None = None
    autoStart: bool | None = None


class StartRelease(DomainBase):
    """Parameters for starting a release from a template."""

    releaseTitle: str | None = None
    folderId: str | None = None
    variables: dict[str, Any] | None = None
    releaseVariables: dict[str, Any] | None = None
    releasePasswordVariables: dict[str, Any] | None = None
    scheduledStartDate: str | None = None
    dueDate: str | None = None
    owner: str | None = None


class ReleasesFilters(DomainBase):
    """Search filters for releases."""

    title: str | None = None
    tags: list[str] | None = None
    taskTags: list[str] | None = None
    statuses: list[str] | None = None
    onlyMine: bool | None = None
    onlyFlagged: bool | None = None
    onlyArchived: bool | None = None
    parentId: str | None = None
    from_: str | None = None
    to: str | None = None
    orderBy: str | None = None
    orderDirection: str | None = None


class Comment(DomainBase):
    """A comment on a task."""

    comment: str | None = None


class Condition(DomainBase):
    """A condition for a gate task."""

    title: str | None = None
    checked: bool | None = None


class VariableOrValue(DomainBase):
    """An object with a variable or value replacing the initial variable."""

    type: str | None = None
    key: str | None = None
    value: Any | None = None


class ImportResult(DomainBase):
    """Result of a template import."""

    id: str | None = None
    type: str | None = None
    status: str | None = None
    message: str | None = None
