from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class Dependency(DomainBase):
    """A dependency in a gate task."""

    id: str | None = None
    type: str | None = None
    target: str | None = None
    targetId: str | None = None


class GateCondition(DomainBase):
    """A condition in a gate task."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    checked: bool | None = None
