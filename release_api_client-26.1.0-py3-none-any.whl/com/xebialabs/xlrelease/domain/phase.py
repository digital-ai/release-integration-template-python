from __future__ import annotations

from datetime import datetime

from com.xebialabs.xlrelease.domain.base import DomainBase
from com.xebialabs.xlrelease.domain.task import Task


class Phase(DomainBase):
    """A phase in a release that contains tasks."""

    id: str | None = None
    title: str | None = None
    description: str | None = None
    owner: str | None = None
    status: str | None = None
    color: str | None = None
    originId: str | None = None
    scheduledStartDate: datetime | None = None
    dueDate: datetime | None = None
    startDate: datetime | None = None
    endDate: datetime | None = None
    plannedDuration: int | None = None
    flagStatus: str | None = None
    flagComment: str | None = None
    tasks: list[Task] | None = None
