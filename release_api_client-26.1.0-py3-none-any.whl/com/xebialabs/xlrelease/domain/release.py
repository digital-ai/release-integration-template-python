from __future__ import annotations

from datetime import datetime
from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase
from com.xebialabs.xlrelease.domain.phase import Phase


class BasicReleaseView(DomainBase):
    """A basic overview of a release."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    startDate: datetime | None = None
    endDate: datetime | None = None
    archived: bool | None = None
    status: str | None = None
    kind: str | None = None


class Release(DomainBase):
    """A release or template in Digital.ai Release."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    description: str | None = None
    owner: str | None = None
    status: str | None = None
    scheduledStartDate: datetime | None = None
    dueDate: datetime | None = None
    startDate: datetime | None = None
    endDate: datetime | None = None
    plannedDuration: int | None = None
    flagStatus: str | None = None
    flagComment: str | None = None
    tags: list[str] | None = None
    phases: list[Phase] | None = None
    queryableStartDate: datetime | None = None
    queryableEndDate: datetime | None = None
    realFlagStatus: str | None = None
    abortComment: str | None = None
    kind: str | None = None
    folderId: str | None = None
    rootReleaseId: str | None = None
    attachments: list[Any] | None = None
    variables: list[Any] | None = None
    calendarLinkToken: str | None = None
    calendarPublished: bool | None = None
    abortOnFailure: bool | None = None
    allowPasswordsInAllFields: bool | None = None
    disableNotifications: bool | None = None
    allowConcurrentReleasesFromTrigger: bool | None = None
    originTemplateId: str | None = None
    createdFromTrigger: bool | None = None
    scriptUsername: str | None = None
    scriptUserPassword: str | None = None
    startedFromTaskId: str | None = None
    parentReleaseId: str | None = None
    variableMapping: dict[str, str] | None = None
    riskProfile: str | None = None
    author: str | None = None
    defaultTargetFolderId: str | None = None
    allowTargetFolderOverride: bool | None = None
    allowRestartInExecutionView: bool | None = None
