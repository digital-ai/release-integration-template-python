from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class TaskReportingRecord(DomainBase):
    """A task reporting record."""

    id: str | None = None
    type: str | None = None
    taskId: str | None = None
    data: dict | None = None


class FacetFilters(DomainBase):
    """Search filters for reporting (facet) records."""

    targetId: str | None = None
    parentId: str | None = None
    types: list[str] | None = None
    releaseIds: list[str] | None = None
    taskIds: list[str] | None = None
    from_: str | None = None
    to: str | None = None


class ItsmRecord(TaskReportingRecord):
    """An ITSM reporting record."""
    pass


class PlanRecord(TaskReportingRecord):
    """A plan reporting record."""
    pass


class BuildRecord(TaskReportingRecord):
    """A build reporting record."""
    pass


class DeploymentRecord(TaskReportingRecord):
    """A deployment reporting record."""
    pass


class CodeComplianceRecord(TaskReportingRecord):
    """A code compliance reporting record."""
    pass
