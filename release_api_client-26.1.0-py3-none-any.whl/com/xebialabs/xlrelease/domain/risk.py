from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class RiskAssessment(DomainBase):
    """A single risk assessment contributing to a release risk score."""

    id: str | None = None
    type: str | None = None
    riskAssessorId: str | None = None
    score: int | None = None
    headline: str | None = None
    messages: list[str] | None = None
    icon: str | None = None


class Risk(DomainBase):
    """The risk score of a release."""

    id: str | None = None
    type: str | None = None
    score: int | None = None
    totalScore: int | None = None
    riskAssessments: list[RiskAssessment] | None = None


class RiskProfile(DomainBase):
    """A risk profile configuration."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    defaultProfile: bool | None = None
    riskProfileAssessors: dict[str, str] | None = None


class RiskGlobalThresholds(DomainBase):
    """The global risk thresholds configuration."""

    id: str | None = None
    type: str | None = None
    atRiskFrom: int | None = None
    attentionNeededFrom: int | None = None


class RiskAssessor(DomainBase):
    """A risk assessor definition."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
