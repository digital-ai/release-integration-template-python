from __future__ import annotations

from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class RolePrincipal(DomainBase):
    """A principal (user) assigned to a role."""

    username: str | None = None
    fullname: str | None = None


class RoleView(DomainBase):
    """A role view in Digital.ai Release."""

    id: str | None = None
    name: str | None = None
    principals: list[RolePrincipal] | None = None
    permissions: list[str] | None = None
