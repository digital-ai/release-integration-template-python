from __future__ import annotations

from datetime import datetime
from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class Task(DomainBase):
    """A task in a phase."""

    id: str | None = None
    title: str | None = None
    description: str | None = None
    owner: str | None = None
    type: str | None = None
    status: str | None = None
    scheduledStartDate: datetime | None = None
    dueDate: datetime | None = None
    startDate: datetime | None = None
    endDate: datetime | None = None
    plannedDuration: int | None = None
    flagStatus: str | None = None
    flagComment: str | None = None
    comments: list[Any] | None = None
    container: str | None = None
    attachments: list[Any] | None = None
    team: str | None = None
    watchers: list[str] | None = None
    hasBeenFlagged: bool | None = None
    hasBeenDelayed: bool | None = None
    preconditionType: str | None = None
    precondition: str | None = None
    failureHandler: str | None = None
    taskFailureHandlerEnabled: bool | None = None
    taskRecoverOp: str | None = None
    failuresCount: int | None = None
    variableMapping: dict[str, str] | None = None
    externalVariableMapping: dict[str, str] | None = None
    tags: list[str] | None = None
    locked: bool | None = None
    checkAttributes: bool | None = None
    statusLine: str | None = None
