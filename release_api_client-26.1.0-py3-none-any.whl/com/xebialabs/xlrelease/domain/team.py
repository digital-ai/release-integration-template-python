from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class TeamView(DomainBase):
    """A team view in Digital.ai Release."""

    id: str | None = None
    teamName: str | None = None
    members: list[TeamMember] | None = None
    permissions: list[str] | None = None
    roles: list[str] | None = None


class TeamMember(DomainBase):
    """A team member."""

    name: str | None = None
    fullName: str | None = None
    type: str | None = None
    roleId: str | None = None
