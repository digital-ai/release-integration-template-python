from __future__ import annotations

from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class Trigger(DomainBase):
    """A trigger in Digital.ai Release."""

    id: str | None = None
    type: str | None = None
    title: str | None = None
    enabled: bool | None = None
    folderId: str | None = None
    template: str | None = None
    templateId: str | None = None
    releaseTitle: str | None = None
    variables: list[Any] | None = None
    pollType: str | None = None
    periodicity: str | None = None
