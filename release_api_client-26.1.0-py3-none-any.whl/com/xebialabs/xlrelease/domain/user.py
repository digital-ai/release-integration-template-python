from __future__ import annotations

from datetime import datetime

from com.xebialabs.xlrelease.domain.base import DomainBase


class UserAccount(DomainBase):
    """A user account in Digital.ai Release."""

    username: str | None = None
    password: str | None = None
    email: str | None = None
    fullName: str | None = None
    loginAllowed: bool | None = None
    external: bool | None = None
    lastActive: datetime | None = None
    profileId: str | None = None
