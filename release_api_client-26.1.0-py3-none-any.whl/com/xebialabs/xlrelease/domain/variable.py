from __future__ import annotations

from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class Variable(DomainBase):
    """A variable in Digital.ai Release."""

    id: str | None = None
    type: str | None = None
    key: str | None = None
    value: Any | None = None
    requiresValue: bool | None = None
    showOnReleaseStart: bool | None = None
    label: str | None = None
    description: str | None = None
    multiline: bool | None = None
    password: bool | None = None
