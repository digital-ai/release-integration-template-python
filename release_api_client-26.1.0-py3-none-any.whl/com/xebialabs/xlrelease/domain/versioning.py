from __future__ import annotations

from com.xebialabs.xlrelease.domain.base import DomainBase


class FolderVersioningSettings(DomainBase):
    """Git versioning settings for a folder."""

    id: str | None = None
    type: str | None = None
    enabled: bool | None = None
    configId: str | None = None
    branch: str | None = None
    path: str | None = None
    versioningStyle: str | None = None


class VersionInfo(DomainBase):
    """Information about a single version."""

    id: str | None = None
    name: str | None = None
    description: str | None = None
    author: str | None = None
    date: str | None = None
    commitId: str | None = None


class VersionsView(DomainBase):
    """A view containing the list of versions for a folder."""

    versions: list[VersionInfo] | None = None
    currentVersion: VersionInfo | None = None


class GitBranch(DomainBase):
    """A Git branch."""

    name: str | None = None
    default: bool | None = None


class ValidationReportMessage(DomainBase):
    """A single validation message."""

    id: str | None = None
    type: str | None = None
    message: str | None = None
    status: str | None = None
    severity: str | None = None


class ValidationReport(DomainBase):
    """A validation report containing validation messages."""

    messages: list[ValidationReportMessage] | None = None
    valid: bool | None = None


class VersioningStyle(DomainBase):
    """A versioning style descriptor."""

    id: str | None = None
    name: str | None = None


class VersionComparisonView(DomainBase):
    """The result of comparing two versions."""

    changes: list[dict] | None = None
    leftVersion: str | None = None
    rightVersion: str | None = None


class CreateVersionForm(DomainBase):
    """The form used to create a new version."""

    versionName: str | None = None
    description: str | None = None


class FoldersWithAppliedVersionInfo(DomainBase):
    """A folder together with its applied version info."""

    folderId: str | None = None
    folderTitle: str | None = None
    appliedVersion: str | None = None
