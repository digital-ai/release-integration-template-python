"""
Compatibility helpers exposed to Jython scripts in Digital.ai Release.

These types (:class:`Logger`, :class:`IDictionary`, :class:`ExternalProperty`)
are not part of the ``xl-release`` public REST API; they mirror objects that are
available in the Jython script context so that existing automation continues to
work when ported to this client.
"""

from com.xebialabs.xlrelease.scripting.dictionary import IDictionary
from com.xebialabs.xlrelease.scripting.external_property import ExternalProperty
from com.xebialabs.xlrelease.scripting.logger import Logger

__all__ = [
    "ExternalProperty",
    "IDictionary",
    "Logger",
]
