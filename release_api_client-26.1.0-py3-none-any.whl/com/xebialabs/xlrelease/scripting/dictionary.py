from __future__ import annotations

from typing import Any, Iterator

from com.xebialabs.xlrelease.domain.base import DomainBase


class IDictionary(DomainBase):
    """
    A dictionary configuration item holding plain and encrypted key/value entries.

    Mirrors the ``udm.Dictionary`` / ``IDictionary`` object available to Jython
    scripts. Plain entries are stored in :attr:`entries`, encrypted entries in
    :attr:`encryptedEntries`.
    """

    id: str | None = None
    type: str | None = "udm.Dictionary"
    entries: dict[str, str] | None = None
    encryptedEntries: dict[str, str] | None = None

    def _all_entries(self) -> dict[str, str]:
        merged: dict[str, str] = {}
        if self.entries:
            merged.update(self.entries)
        if self.encryptedEntries:
            merged.update(self.encryptedEntries)
        return merged

    def get(self, key: str, default: Any = None) -> Any:
        """Returns the value for the given key, or ``default`` if absent."""
        return self._all_entries().get(key, default)

    def put(self, key: str, value: str) -> None:
        """Adds or updates a plain entry."""
        if self.entries is None:
            self.entries = {}
        self.entries[key] = value

    def putEncrypted(self, key: str, value: str) -> None:
        """Adds or updates an encrypted entry."""
        if self.encryptedEntries is None:
            self.encryptedEntries = {}
        self.encryptedEntries[key] = value

    def remove(self, key: str) -> None:
        """Removes an entry (plain or encrypted) if present."""
        if self.entries and key in self.entries:
            del self.entries[key]
        if self.encryptedEntries and key in self.encryptedEntries:
            del self.encryptedEntries[key]

    def containsKey(self, key: str) -> bool:
        """Returns whether the dictionary contains the given key."""
        return key in self._all_entries()

    def keys(self) -> list[str]:
        """Returns the list of all keys (plain and encrypted)."""
        return list(self._all_entries().keys())

    def values(self) -> list[str]:
        """Returns the list of all values (plain and encrypted)."""
        return list(self._all_entries().values())

    def items(self) -> list[tuple[str, str]]:
        """Returns the list of all (key, value) pairs."""
        return list(self._all_entries().items())

    def __getitem__(self, key: str) -> str:
        entries = self._all_entries()
        if key not in entries:
            raise KeyError(key)
        return entries[key]

    def __setitem__(self, key: str, value: str) -> None:
        self.put(key, value)

    def __contains__(self, key: object) -> bool:
        return isinstance(key, str) and self.containsKey(key)

    def __iter__(self) -> Iterator[str]:  # type: ignore[override]
        return iter(self._all_entries())

    def __len__(self) -> int:
        return len(self._all_entries())
