from __future__ import annotations

from typing import Any

from com.xebialabs.xlrelease.domain.base import DomainBase


class ExternalProperty(DomainBase):
    """
    A reference to a property whose value is stored in an external secret store
    (for example, HashiCorp Vault or CyberArk).

    Mirrors the ``ExternalProperty`` object used in the Jython script context. It
    keeps the lookup key/path together with an optionally resolved value.
    """

    id: str | None = None
    type: str | None = "xlrelease.ExternalProperty"
    key: str | None = None
    path: str | None = None
    provider: str | None = None
    value: str | None = None

    def getValue(self) -> Any:
        """Returns the resolved value of the external property."""
        return self.value

    def setValue(self, value: str) -> None:
        """Sets the resolved value of the external property."""
        self.value = value

    def getKey(self) -> str | None:
        """Returns the lookup key of the external property."""
        return self.key

    def __str__(self) -> str:
        return self.value if self.value is not None else ""
