from __future__ import annotations

import logging
from typing import Any


class Logger:
    """
    A thin wrapper around the standard :mod:`logging` module that mirrors the
    ``logger`` object available inside Digital.ai Release Jython script tasks.

    It exposes the Java-style ``debug``/``info``/``warn``/``error`` methods so
    that scripts written against the in-product logger keep working.
    """

    def __init__(self, name: str = "xlrelease.script", level: int | None = None):
        """
        Initializes the Logger.

        :param name: the logger name.
        :param level: an optional logging level to apply to the underlying logger.
        """
        self._logger = logging.getLogger(name)
        if level is not None:
            self._logger.setLevel(level)
        if not self._logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
            self._logger.addHandler(handler)

    @staticmethod
    def _format(message: str, *args: Any) -> str:
        """Formats a message using SLF4J-style ``{}`` placeholders or printf style."""
        if not args:
            return message
        if "{}" in message:
            result = message
            for arg in args:
                result = result.replace("{}", str(arg), 1)
            return result
        try:
            return message % args
        except (TypeError, ValueError):
            return message + " " + " ".join(str(a) for a in args)

    def debug(self, message: str, *args: Any) -> None:
        """Logs a message at DEBUG level."""
        self._logger.debug(self._format(message, *args))

    def info(self, message: str, *args: Any) -> None:
        """Logs a message at INFO level."""
        self._logger.info(self._format(message, *args))

    def warn(self, message: str, *args: Any) -> None:
        """Logs a message at WARN level."""
        self._logger.warning(self._format(message, *args))

    # Alias for the Python-style name.
    warning = warn

    def error(self, message: str, *args: Any) -> None:
        """Logs a message at ERROR level."""
        self._logger.error(self._format(message, *args))

    def isDebugEnabled(self) -> bool:
        """Returns whether DEBUG level logging is enabled."""
        return self._logger.isEnabledFor(logging.DEBUG)

    def isInfoEnabled(self) -> bool:
        """Returns whether INFO level logging is enabled."""
        return self._logger.isEnabledFor(logging.INFO)
