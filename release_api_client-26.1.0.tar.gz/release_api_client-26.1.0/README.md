# release-api-client-python

A Python API client for **Digital.ai Release**.

It is the Python equivalent of the Digital.ai Release **Jython API**
([`xl-release` 26.1.x](https://apidocs.digital.ai/jython-docs/#!/xl-release/26.1.x)) —
the same `com.xebialabs.xlrelease` packages and **camelCase** method names, so
existing Release automation scripts port to Python with minimal changes.

## Project Overview

Digital.ai Release is a release-orchestration platform for planning, automating,
and tracking software delivery pipelines. It exposes a REST API (`/api/v1`) for
managing releases, templates, phases, tasks, folders, environments, and more.

`release-api-client-python` wraps that REST API in a clean, object-oriented
Python interface. Instead of hand-crafting HTTP requests and parsing raw JSON,
you call typed API classes (`ReleaseApi`, `TemplateApi`, `FolderApi`, `TaskApi`,
`EnvironmentApi`, …) that return strongly-typed [Pydantic](https://docs.pydantic.dev/)
models (`Release`, `Phase`, `Task`, `Variable`, …).

HTTP transport and authentication are handled by the official
[`digitalai-release-sdk`](https://pypi.org/project/digitalai-release-sdk/), which
provides the underlying `ReleaseAPIClient`.

## Key Features

- **Full REST surface** — 29 API classes covering releases, templates, phases,
  tasks, folders, variables, teams, roles, users, environments, deliveries, risk,
  reporting, configuration, triggers, and Git "as-code" folder versioning.
- **Typed domain models** — every request/response maps to a Pydantic v2 model;
  unknown server fields round-trip safely (`extra="allow"`).
- **Jython-compatible** — camelCase methods and aliases (`create`, `getById`,
  `update`, `search`) match the Java/Jython public API.
- **Flexible authentication** — HTTP basic auth or a personal access token.
- **Live integration test suite** — one test module per API class.

## Installation

Requires **Python >= 3.11**. Dependencies: `digitalai-release-sdk` and `pydantic`.

```bash
# Using uv (recommended)
uv sync

# Or using pip
pip install -e .
```

## Authentication

The client connects to a running Release server (default `http://localhost:5516`).

```python
from digitalai.release.release_api_client import ReleaseAPIClient

# Option 1 — username / password (HTTP basic auth)
client = ReleaseAPIClient("http://localhost:5516", "admin", "admin")

# Option 2 — personal access token
client = ReleaseAPIClient(
    "http://localhost:5516",
    personal_access_token="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
)

# The client is a context manager and closes its session on exit
with ReleaseAPIClient("http://localhost:5516", "admin", "admin") as client:
    ...
```

**Option 3 — inside a Release container task.** When your code runs as a custom
task (a subclass of `BaseTask` from the integration SDK), call
`self.get_release_api_client()` to get a client already configured from the
task's "Run as user" context — no URL or credentials needed:

```python
from digitalai.release.integration.base_task import BaseTask
from com.xebialabs.xlrelease.api.v1.release_api import ReleaseApi


class MyTask(BaseTask):
    def execute(self) -> None:
        client = self.get_release_api_client()
        releases = ReleaseApi(client).getReleases()
        ...
```

## Usage Examples

Wrap an authenticated `ReleaseAPIClient` with the API class you need. Method names
use camelCase to match the Digital.ai Release public API.

### List and get releases

```python
from com.xebialabs.xlrelease.api.v1.release_api import ReleaseApi

release_api = ReleaseApi(client)

# All visible releases (optional pagination)
releases = release_api.getReleases(page=0, resultsPerPage=50)
for release in releases:
    print(release.id, release.title, release.status)

# A single release by id
release = release_api.getRelease("Applications/Releasexxxxxxxx")

# Search by title
matches = release_api.searchReleasesByTitle("Release 1.0.0")
```

### Create a release from a template

```python
from com.xebialabs.xlrelease.api.v1.template_api import TemplateApi
from com.xebialabs.xlrelease.domain.forms import CreateRelease
from com.xebialabs.xlrelease.domain.release import Release

template_api = TemplateApi(client)

# Create a template (id/type/status are auto-filled when omitted)
template = template_api.createTemplate(Release(title="Deployment Template"))

# Create a release from it
release = template_api.create(template.id, CreateRelease(releaseTitle="Release 1.0.0"))
print("Created release:", release.id)
```

### Update and delete a release

```python
# Fetch, mutate, persist
release = release_api.getRelease("Applications/Releasexxxxxxxx")
release.description = "Updated via the Python client"
release_api.updateRelease(release.id, release)

# Abort (optionally with a reason), then delete
release_api.abort("Applications/Releasexxxxxxxx", "Superseded by 1.0.1")
release_api.delete("Applications/Releasexxxxxxxx")
```

### Folders, variables, phases, and tasks

```python
from com.xebialabs.xlrelease.api.v1.folder_api import FolderApi
from com.xebialabs.xlrelease.api.v1.phase_api import PhaseApi
from com.xebialabs.xlrelease.api.v1.task_api import TaskApi
from com.xebialabs.xlrelease.domain.folder import Folder
from com.xebialabs.xlrelease.domain.phase import Phase
from com.xebialabs.xlrelease.domain.task import Task
from com.xebialabs.xlrelease.domain.variable import Variable

# Folders
folder_api = FolderApi(client)
root = folder_api.listRoot()[0]
folder_api.addFolder(root.id, Folder(title="Team A"))

# Release variables
release_api.createVariable(
    "Applications/Releasexxxxxxxx",
    Variable(type="xlrelease.StringVariable", key="env", value="prod"),
)

# Phases and tasks
phase = PhaseApi(client).addPhase(template.id, Phase(title="Build"))
TaskApi(client).addTask(phase.id, Task(title="Compile", type="xlrelease.Task"))
```

### Error handling

API methods call `raise_for_status()`, so non-2xx responses raise
`requests.exceptions.HTTPError`:

```python
import requests

try:
    release_api.getRelease("Applications/Releasedoesnotexist")
except requests.exceptions.HTTPError as exc:
    print("Request failed:", exc.response.status_code)
```

## Developer Instructions

The project uses [`uv`](https://docs.astral.sh/uv/) for dependency management and
[`hatchling`](https://hatch.pypa.io/latest/) as the build backend.

### Set up a dev environment

```bash
# Installs runtime + dev dependencies into a managed virtual environment
uv sync --extra dev
```

Layout:

```text
src/com/xebialabs/xlrelease/
├── api/v1/      # API client classes (one per REST resource)
├── domain/     # Pydantic models (Release, Phase, Task, ...) and request forms
└── scripting/  # Jython script-context helpers (Logger, IDictionary, ...)
tests/          # Live integration tests (one module per API class)
```

Guidelines:

- Preserve the Java/Jython **camelCase** method names and parameter order so
  existing scripts keep working.
- Map requests and responses to Pydantic models that extend `DomainBase`; avoid
  passing raw dictionaries in public signatures.
- Cover every public method with an integration test, and clean up anything the
  test creates in `tearDown`/`finally`.

### Build Instructions

The wheel packages the `src/com` tree.

```bash
# Build both sdist and wheel into ./dist
uv build

# Or build a single artifact
uv build --wheel
uv build --sdist
```

Install the built wheel:

```bash
pip install dist/release_api_client-26.1.0-py3-none-any.whl
```

### Run Integration Tests

> **Note:** the suite runs **live** against a real Digital.ai Release server.
> By default it expects `http://localhost:5516` with credentials `admin` / `admin`.
> Start a Release instance (or adjust the test setup) before running.

```bash
# Run everything
uv run pytest

# Verbose, and show reasons for skipped tests
pytest -v -rs

# Run a single module or test
pytest tests/test_release_api.py
pytest tests/test_release_api.py::TestReleaseApi::test_02_get_release
```

## License

Licensed under the [MIT License](https://opensource.org/licenses/MIT).
