# release-api-client-python

A Python API client for **Digital.ai Release**.

It is the Python equivalent of the Digital.ai Release **Jython API**
([`xl-release`](https://apidocs.digital.ai/jython-docs/#!/xl-release/26.1.x)) —
the same `com.xebialabs.xlrelease` packages and **camelCase** method names, so
existing Release automation scripts port to Python with minimal changes.


## Installation

Requires **Python >= 3.11**. Dependencies: `digitalai-release-sdk` and `pydantic`.

```bash
# Using uv (recommended)
uv sync

# Or using pip
pip install -e .
```

## Authentication and usage

The client connects to a running Release server (default `http://localhost:5516`).
Build a `ReleaseAPIClient`, then wrap it with the API class you need — method
names use **camelCase** to match the Digital.ai Release public API.

### Option 1 — username / password (HTTP basic auth)

```python
from digitalai.release.release_api_client import ReleaseAPIClient
from com.xebialabs.xlrelease.api.v1.release_api import ReleaseApi

client = ReleaseAPIClient("http://localhost:5516", "admin", "admin")
release = ReleaseApi(client).getRelease("Applications/Releasexxxxxxxx")
print(release.id, release.title, release.status)
```

### Option 2 — personal access token

```python
from digitalai.release.release_api_client import ReleaseAPIClient
from com.xebialabs.xlrelease.api.v1.release_api import ReleaseApi

client = ReleaseAPIClient(
    "http://localhost:5516",
    personal_access_token="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
)
release = ReleaseApi(client).getRelease("Applications/Releasexxxxxxxx")
print(release.id, release.title, release.status)
```

### Option 3 — inside a Release container task

When your code runs as a custom task (a subclass of `BaseTask` from the
integration SDK), call `self.get_release_api_client()` to get a client already
configured from the task's "Run as user" context — no URL or credentials needed:

```python
from digitalai.release.integration.base_task import BaseTask
from com.xebialabs.xlrelease.api.v1.release_api import ReleaseApi


class MyTask(BaseTask):
    def execute(self) -> None:
        client = self.get_release_api_client()
        release = ReleaseApi(client).getRelease("Applications/Releasexxxxxxxx")
        print(release.id, release.title, release.status)
```

### Option 4 — subclass `ApiBaseTask` instead of `BaseTask`

To skip the boilerplate, subclass `ApiBaseTask`. It exposes every v1 API as a
lazily created property (`releaseApi`, `phaseApi`, `taskApi`, ... — one per API
class), all sharing a single client built from the task's "Run as user" context.
The client and each API object are created on first access and cached for the
life of the task (call `self.reset_api_clients()` to force a rebuild):

```python
from com.xebialabs.xlrelease.api.v1.api_base_task import ApiBaseTask


class MyTask(ApiBaseTask):
    def execute(self) -> None:
        release = self.releaseApi.getRelease("Applications/Releasexxxxxxxx")
        print(release.id, release.title, release.status)
```

## Developer Instructions

The project uses [`uv`](https://docs.astral.sh/uv/) for dependency management and
[`hatchling`](https://hatch.pypa.io/latest/) as the build backend.

### Set up a dev environment

```bash
# Installs runtime + dev dependencies into a managed virtual environment
uv sync --extra dev
```

Layout:

```text
src/com/xebialabs/xlrelease/
├── api/v1/      # API client classes (one per REST resource)
├── domain/     # Pydantic models (Release, Phase, Task, ...) and request forms
└── scripting/  # Jython script-context helpers (Logger, IDictionary, ...)
tests/          # Live integration tests (one module per API class)
```

Guidelines:

- Preserve the Java/Jython **camelCase** method names and parameter order so
  existing scripts keep working.
- Map requests and responses to Pydantic models that extend `DomainBase`; avoid
  passing raw dictionaries in public signatures.
- Cover every public method with an integration test, and clean up anything the
  test creates in `tearDown`/`finally`.

### Build Instructions

The wheel packages the `src/com` tree.

```bash
# Build both sdist and wheel into ./dist
uv build

# Or build a single artifact
uv build --wheel
uv build --sdist
```

Install the built wheel:

```bash
pip install dist/release_api_client-26.1.0-py3-none-any.whl
```

### Run Integration Tests

> **Note:** the suite runs **live** against a real Digital.ai Release server.
> By default it expects `http://localhost:5516` with credentials `admin` / `admin`.
> Start a Release instance (or adjust the test setup) before running.

```bash
# Run everything
uv run pytest

# Verbose, and show reasons for skipped tests
pytest -v -rs

# Run a single module or test
pytest tests/test_release_api.py
pytest tests/test_release_api.py::TestReleaseApi::test_02_get_release
```

## License

Licensed under the [MIT License](https://opensource.org/licenses/MIT).
